
//#include "main.h"

//#include "string.h"
#include "stdio.h"

#include "mco.h"
//#include "delay.h"
//#include "led.h"
//#include "led2.h"
//#include "led3.h"
//#include "beep.h"
#include "uart-poll.h"
//#include "uart-nvic.h"
//#//include "key-exti.h"
//#include "systick.h"
//#include "rtc.h"
//#include "rs485.h"
//#include "i2c.h"
//#include "spi.h"
//#include "iwdg.h"
//#include "wwdg.h"
//#include "hc_sr501.h"
//#include "sr501.h"
//#include "r04.h"
#include "dht11.h"
int main(void)
{
	//uint16_t id;
	char str[1];
	unsigned char temperature=0;
  unsigned char humidity=0;
  
	// 初始化 SysTick
	//SysTick_init();
	
	// 设置优先级分组2：抢占优先级和响应优先级各占两位，即各 4 级
	//NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
		
  /* Add your application code here */
  /* Insert 50 ms delay */
  //Delay(5);
	//delay_ms(50);
	
	// 初始化 MCO1 和 MCO2
  MCO_init();
  // 初始化 LED
	//LED_init3();
	// 初始化蜂鸣器
	//BEEP_init();
	// 初始化按键
	//KEY_init();
	// 初始化 USART1
	USART1_poll_init(115200);
	//USART1_nvic_init(115200);
	//KEY_exti_init();
	// 初始化 RTC
	//RTC_init();
	// 初始化 RS485
	//RS485_init(115200);
	// 初始化 I2C1
	//I2C1_init();
	// 初始化 SPI1
	//SPI1_w25q128_init();
	// 初始化独立看门狗
	// 32KHz / 256 = 125Hz
	//IWDG_init(IWDG_Prescaler_256, 250);
	// 喂狗
	//IWDG_ReloadCounter();
	// 初始化窗口看门狗
	//WWDG_init(WWDG_Prescaler_8, 0x70, 0x7F);
	
	//printf("\nStarting ...\n");
//HC_SR501Configuration();
//SR501_init();
//Hcsr04Init();
//hcsr04_NVIC();
DHT11_Init();//初始化DHT1
  /* Infinite loop */
  while (1)
  {
		//HC_SR501_Status();
		//sr501_test();
		
		
		//printf("A distance of:%f\n",Hcsr04GetLength());
		
				DHT11_Read_Data(&temperature,&humidity);		//读取温湿度值
        printf("temperature：%d    humidity:%d\r\n",temperature,humidity);
        delay_Ms(500);


  }
}





























#ifdef  USE_FULL_ASSERT



/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif

/**
  * @}
  */


/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
