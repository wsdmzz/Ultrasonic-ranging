#ifndef __DHT11_H
#define __DHT11_H 
   
#include "stm32f4xx.h"


//IO��������
#define DHT11_IO_IN()  {GPIOG->MODER&=~(3<<(9*2));GPIOE->MODER|=0<<9*2;}	// 00 PG9����ģʽ
#define DHT11_IO_OUT() {GPIOG->MODER&=~(3<<(9*2));GPIOE->MODER|=1<<9*2;} 	// 01 PG9���ģʽ 

 
unsigned char DHT11_Init(void);
void DHT11_Rst();
unsigned char DHT11_Check();
unsigned char DHT11_Read_Bit(void);
unsigned char DHT11_Read_Byte(void);
unsigned char DHT11_Read_Data(unsigned char *temp,unsigned char *humi);
void delay_Ms(uint16_t time);
void delay_Us(uint16_t time);
#endif
