#include "hc_sr501.h"


void HC_SR501Configuration(void)
{
	GPIO_InitTypeDef GPIO_InitStructer;
    
    //Enable APB2 Bus
    RCC_APB1PeriphClockCmd(RCC_AHB1Periph_GPIOB,ENABLE);
    
    //Register IO 
    GPIO_InitStructer.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStructer.GPIO_Mode  = GPIO_Mode_IN;
		GPIO_InitStructer.GPIO_OType = GPIO_OType_PP;
		GPIO_InitStructer.GPIO_PuPd = GPIO_PuPd_DOWN;
    GPIO_Init(GPIOB, &GPIO_InitStructer);
		//GPIO_ResetBits(GPIOA, GPIO_Pin_10);
}

void HC_SR501_Status(void)
{
	while(0 !=GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_10))
	{
	if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_10) == 1)
	{
		beeps(2, 20);
		
		//Delay(5);
		
		break;
	}
	else
	{
		//BEEP_OFF();
	}
}
	Delay(100);
}	
