#ifndef __HC_SR501_H__
#define	__HC_SR501_H__

#include "stm32f4xx.h"
//#include "bit_bauding.h"
#include "beep.h"
#include "delay.h"




void HC_SR501Configuration(void);
void HC_SR501_Status(void);
#endif
