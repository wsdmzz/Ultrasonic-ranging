#include "adc.h"
#include "systick.h"

/*
	查原理图得知：
	
	STM_ADC  --  PA5 / ADC1/2_IN5
	
	从可调电阻传入的电压值，可以从 ADC1 或 ADC2 的通道 5 转换为数字信号。
	这个过程也称为"编码"。
	
	Vref+ 通过 P10 跳线连接 VDDA3V3 电源
*/

/**
 * 功能：  初始化 ADC1 通道 5，对 PA5 输入电压进行转换
 * 参数：  prescaler 预分频值：
 *             ADC_Prescaler_Div2
 *             ADC_Prescaler_Div4
 *             ADC_Prescaler_Div6
 *             ADC_Prescaler_Div8
 * 返回值：无
 **/
void ADC1_PA5_init(uint32_t prescaler)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	ADC_CommonInitTypeDef ADC_CommonInitStructure;
	ADC_InitTypeDef ADC_InitStructure;
	
	// 使能 GPIOA, ADC1 时钟
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);
	
	// 初始化 PA5
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;  // 模拟
	// 模拟功能时不用配置 GPIO_OType 和 GPIO_Speed
	//GPIO_InitStructure.GPIO_OType = ;
	//GPIO_InitStructure.GPIO_Speed = ;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	// ADC 的通用初始化（ADC1/ADC2/ADC3 共同的配置）
	ADC_CommonInitStructure.ADC_DMAAccessMode = ADC_DMAAccessMode_Disabled;
	ADC_CommonInitStructure.ADC_Mode = ADC_Mode_Independent;
	ADC_CommonInitStructure.ADC_Prescaler = prescaler;
	// 连续模式时，两次采样之间的间隔周期，对于单次模式可以不配置
	ADC_CommonInitStructure.ADC_TwoSamplingDelay = ADC_TwoSamplingDelay_5Cycles;
	ADC_CommonInit(&ADC_CommonInitStructure);
	
	// ADC1 的初始化
	ADC_InitStructure.ADC_ContinuousConvMode = DISABLE; // 禁用连续转换
	ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;  // 转换结果数据右对齐
	// 不使用外部触发转换
	ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_T1_CC1;
	ADC_InitStructure.ADC_ExternalTrigConvEdge = ADC_ExternalTrigConvEdge_None;
	ADC_InitStructure.ADC_NbrOfConversion = 1;  // 1 个通道
	ADC_InitStructure.ADC_Resolution = ADC_Resolution_12b;  // 12 位分辨率
	ADC_InitStructure.ADC_ScanConvMode = DISABLE;  // 禁用扫描
	ADC_Init(ADC1, &ADC_InitStructure);
	
	// 使能 ADC1
	ADC_Cmd(ADC1, ENABLE);
}

// void ADC_RegularChannelConfig(ADC_TypeDef* ADCx, uint8_t ADC_Channel, uint8_t Rank, uint8_t ADC_SampleTime);
// void ADC_SoftwareStartConv(ADC_TypeDef* ADCx);
// FlagStatus ADC_GetSoftwareStartConvStatus(ADC_TypeDef* ADCx);
// uint16_t ADC_GetConversionValue(ADC_TypeDef* ADCx);
// FlagStatus ADC_GetFlagStatus(ADC_TypeDef* ADCx, uint8_t ADC_FLAG);

/**
 * 功能：  获取单次转换数据
 * 参数：  无
 * 返回值：转换结果数据
 **/
uint16_t ADC1_IN5_get_value(void)
{
	// 配置规则通道
	ADC_RegularChannelConfig(ADC1, ADC_Channel_5, 1, ADC_SampleTime_480Cycles);
	// 软件触发开始转换
	ADC_SoftwareStartConv(ADC1);
	// 等待转换结束
	while (RESET == ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC));
	
	return ADC_GetConversionValue(ADC1);
}

/**
 * 功能：  获取 n 次转换的平均数据
 * 参数：  n 转换的次数
 * 返回值：转换结果平均数据
 **/
uint16_t ADC1_IN5_get_avg_value(int n)
{
	uint32_t total = 0;
	int i;
	
	for (i = 0; i < n; i++)
	{
		total += ADC1_IN5_get_value();
		delay_ms(10);
	}
	
	return total / n;
}

/**
 * 功能：  获取 n 次转换的平均电压值
 * 参数：  n 转换的次数
 * 返回值：转换结果平均电压
 **/
float ADC1_IN5_get_vol(int n)
{
	uint16_t avg;
	
	avg = ADC1_IN5_get_avg_value(n);
	
	return 3.3f * avg / 4096;
}
