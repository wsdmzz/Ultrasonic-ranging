#ifndef _ADC_H_
#define _ADC_H_

#include "stm32f4xx.h"

/**
 * 功能：  初始化 ADC1 通道 5，对 PA5 输入电压进行转换
 * 参数：  prescaler 预分频值：
 *             ADC_Prescaler_Div2
 *             ADC_Prescaler_Div4
 *             ADC_Prescaler_Div6
 *             ADC_Prescaler_Div8
 * 返回值：无
 **/
void ADC1_PA5_init(uint32_t prescaler);

/**
 * 功能：  获取单次转换数据
 * 参数：  无
 * 返回值：转换结果数据
 **/
uint16_t ADC1_IN5_get_value(void);

/**
 * 功能：  获取 n 次转换的平均数据
 * 参数：  n 转换的次数
 * 返回值：转换结果平均数据
 **/
uint16_t ADC1_IN5_get_avg_value(int n);

/**
 * 功能：  获取 n 次转换的平均电压值
 * 参数：  n 转换的次数
 * 返回值：转换结果平均电压
 **/
float ADC1_IN5_get_vol(int n);

#endif
