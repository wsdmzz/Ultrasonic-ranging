#include "beep.h"
#include "delay.h"
#include "systick.h"

/*
	BEEP --  PF8
*/

/**
 * 功能：  初始化蜂鸣器
 * 参数：  无
 * 返回值：无
 **/
void BEEP_init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	
	// 使能 GPIOF 时钟
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOF, ENABLE);
	
	// 配置 PF8 
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;   // 通用输出
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;  // 推挽
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_8;       // PF8
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;    // 上拉
	GPIO_InitStruct.GPIO_Speed = GPIO_High_Speed;  // 高速
	GPIO_Init(GPIOF, &GPIO_InitStruct);
	
	// 默认关闭蜂鸣器
	BEEP_OFF();
}

/**
 * 功能：  蜂鸣器每隔 interval 时间长鸣叫 conut 次
 * 参数：  count 鸣叫次数
 *         interval 间隔时长(单位：10ms)
 * 返回值：无
 **/
void beeps(int count, int interval)
{
	int i;
	
	for (i = 0; i < count; i++)
	{
		BEEP_ON();
		Delay(interval);
		delay_ms(interval * 10);
		BEEP_OFF();
		Delay(interval);
		delay_ms(interval * 10);
	}
	BEEP_OFF();
}
