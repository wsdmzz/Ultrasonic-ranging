#ifndef _BEEP_H_
#define _BEEP_H_

#include "stm32f4xx.h"

// 定义蜂鸣器开启和关闭宏
#define BEEP_OFF() do { GPIO_ResetBits(GPIOF, GPIO_Pin_8); } while (0)
#define BEEP_ON()  do { GPIO_SetBits(GPIOF, GPIO_Pin_8); } while (0)

#define BEEP  (*(volatile uint32_t *)(BIT_WORD_ADDR(0x42000000, 0x00021414, 8)))

/**
 * 功能：  初始化蜂鸣器
 * 参数：  无
 * 返回值：无
 **/
void BEEP_init(void);

/**
 * 功能：  蜂鸣器每隔 interval 时间长鸣叫 conut 次
 * 参数：  count 鸣叫次数
 *         interval 间隔时长(单位：10ms)
 * 返回值：无
 **/
void beeps(int count, int interval);

#endif
