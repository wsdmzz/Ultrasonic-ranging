
#ifndef _BIT_BAUDING_H_
#define _BIT_BAUDING_H_

// 计算位段区域某个位到位段别名区域的地址映射
// bit_word_offset = (byte_offset x 32) + (bit_number x 4)
// bit_word_addr = bit_band_base + bit_word_offset

#define BIT_WORD_OFFSET(byte_offset, bit_number) \
	(((byte_offset) * 32) + ((bit_number) * 4))
#define BIT_WORD_ADDR(bit_band_base, byte_offset, bit_number) \
	(bit_band_base + BIT_WORD_OFFSET(byte_offset, bit_number))

#endif
