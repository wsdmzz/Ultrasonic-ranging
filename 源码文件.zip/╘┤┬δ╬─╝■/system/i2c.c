
#include "i2c.h"
#include "systick.h"

/*
	查原理图：
	
	MCU 外接了以下器件：
	1. 24C02 EEPROM
	2. MPU6050 三轴陀螺仪和加速度计
	3. WM8978 声卡
	另外还有一个 P3 对外接口，用于外接其他器件。
	
	IIC_SCL -- PB8 -- 复用于 I2C1_SCL
	IIC_SDA -- PB9 -- 复用于 I2C1_SDA
*/

/**
 * 功能：  初始化 I2C1
 * 参数：  无
 * 返回值：无
 **/
void I2C1_init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	I2C_InitTypeDef I2C_InitStructure;
	
	// 使能 GPIOB 时钟
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
	
	// 使能 I2C1 时钟
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C1, ENABLE);
	
	// 配置 PB8, PB9 复用功能
	GPIO_PinAFConfig(GPIOB, GPIO_PinSource8, GPIO_AF_I2C1);
	GPIO_PinAFConfig(GPIOB, GPIO_PinSource9, GPIO_AF_I2C1);
	
	// 初始化 PB8, PB9
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	// 开漏
	GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	// 初始化 I2C1
	I2C_InitStructure.I2C_Ack = I2C_Ack_Enable;
	I2C_InitStructure.I2C_AcknowledgedAddress = I2C_AcknowledgedAddress_7bit;
	// 支持 标准速度 100KHz 和 快速速度 400KHz
	I2C_InitStructure.I2C_ClockSpeed = 100000;  // 100KHz
	// 一个时钟周期内，低电平时间与高电平时间的比例，称为占空比
	// 占空比 t_low : t_high = 2:1，另外还支持 16:9
	I2C_InitStructure.I2C_DutyCycle = I2C_DutyCycle_2;
	// 支持 I2C 和 SMB 
	I2C_InitStructure.I2C_Mode = I2C_Mode_I2C;
	// MCU 在 I2C 总线上的自有地址
	I2C_InitStructure.I2C_OwnAddress1 = I2C_OwnAddress;
	// 使能 I2C1
	// void I2C_Cmd(I2C_TypeDef* I2Cx, FunctionalState NewState);
	I2C_Cmd(I2C1, ENABLE);
	I2C_Init(I2C1, &I2C_InitStructure);
}

// void I2C_SendData(I2C_TypeDef* I2Cx, uint8_t Data);
// uint8_t I2C_ReceiveData(I2C_TypeDef* I2Cx);

/*
	24C02 相关数据：
	2048位(256Byte * 8 bits)存储空间
	可按字节写，也可按页写，页大小为 8 字节
	可按字节、随机、序列读
	自动递增地址
	A2,A1,A0 是地址输入引脚，因此一个 I2C 总线上可接 8 个同样的 24C02 芯片
	24C02 器件寻址：
	1 0 1 0 A2 A1 A0 Rw
	通过原理图可知，24C02 的 A2,A1,A0 都接地，因此开发板上的 24C02 
	的地址为：
	0b10100000
	即：0xA0
	地址的第 [0] 位是表示要读还是写，0 表示写，1 表示读
*/

/*
	字节写：
	1. 起始条件
	2. 总线上器件寻址
	3. 器件应答
	4. 器件内寻址
	5. 器件应答
	6. 写入一字节数据
	7. 器件应答
	8. 停止条件
*/

// 定义超时值
#define sEE_FLAG_TIMEOUT         ((uint32_t)0x1000)
#define sEE_LONG_TIMEOUT         ((uint32_t)(30 * sEE_FLAG_TIMEOUT))

__IO uint32_t sEETimeout = sEE_LONG_TIMEOUT;  

/**
 * 功能：  I2C1 写入 24C02 EEPROM 一个字节数据
 * 参数：  addr 24C02 内偏移地址
 *         data 要写入的一字节数据
 * 返回值：成功返回 0，失败返回 -1
 **/
int I2C1_24c02_write_byte(uint8_t addr, uint8_t data)
{
	/* 总线忙等待 */
  sEETimeout = sEE_LONG_TIMEOUT;
  while(I2C_GetFlagStatus(I2C1, I2C_FLAG_BUSY))
  {
    if((sEETimeout--) == 0) return -1;
  }
	
	/* 起始条件 */
  I2C_GenerateSTART(I2C1, ENABLE);
	
	/* 测试 EV5 并清除它 */
  sEETimeout = sEE_FLAG_TIMEOUT;
  while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_MODE_SELECT))
  {
    if((sEETimeout--) == 0) return -1;
  }
	
	// 
	/* 器件寻址，用于写操作 */
  sEETimeout = sEE_FLAG_TIMEOUT;
  I2C_Send7bitAddress(I2C1, I2C_24C02_Address, I2C_Direction_Transmitter);
	
	/* 测试 EV6 并清除它 */
  sEETimeout = sEE_FLAG_TIMEOUT;
  while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED))
  {
    if((sEETimeout--) == 0) return -1;
  }
	
	/* 测试 EV8 并清除它 */
  sEETimeout = sEE_FLAG_TIMEOUT; 
  while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_BYTE_TRANSMITTING))
  {
    if((sEETimeout--) == 0) return -1;
  }  
	
	// 发送要写的一个字节的地址
	I2C_SendData(I2C1, addr);
	
	// 测试 EV8 事件并清除它
	sEETimeout = sEE_FLAG_TIMEOUT; 
  while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_BYTE_TRANSMITTING))
  {
    if((sEETimeout--) == 0) return -1;
  } 
	
	/* 发送数据 */
	I2C_SendData(I2C1, data);
	
	/* 测试 EV8_2 并清除它 */
  sEETimeout = sEE_FLAG_TIMEOUT; 
  while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_BYTE_TRANSMITTED))
  {
    if((sEETimeout--) == 0) return -1;
  }  
	
	#if 0
	/* 待总线上所有数据发送完毕 */
	sEETimeout = sEE_LONG_TIMEOUT;
	while(!I2C_GetFlagStatus(I2C1, I2C_FLAG_BTF))
	{
		if((sEETimeout--) == 0) return -1;
	}
	#endif
	
	/* 停止条件 */
  I2C_GenerateSTOP(I2C1, ENABLE);
	
	// 等待停止位被清除
	sEETimeout = sEE_FLAG_TIMEOUT;
	while(I2C1->CR1 & I2C_CR1_STOP)
	{
		if((sEETimeout--) == 0) return -1;
	} 
	
	// 如果多次写出错，可以考虑延时一会
	delay_ms(5);
	
	return 0;
}


/**
 * 功能：  从 24C02 的 addr 处读取最多 size 个字节到 buf 中
 * 参数：  buf  存放读取的数据缓冲区
 *         addr 24C02 内读取的超始地址
 *         size 要读取的字节数
 * 返回值：成功返回实际读取的字节数，失败返回 -1
 **/
int I2C1_24c02_ReadBuffer(uint8_t* buf, uint8_t addr, uint8_t size)
{
	__IO uint32_t  sEETimeout = sEE_LONG_TIMEOUT;
	int i;
	
	// 0 个不读取
	if (0 == size)
	{
		return 0;
	}
	
	// 避免超过 24C02 芯片内存范围
	if (addr + size > M24C02_CAP)
	{
		size = M24C02_CAP - addr;
	}
	
	// 总线忙等待
  while(I2C_GetFlagStatus(I2C1, I2C_FLAG_BUSY))
  {
    if((sEETimeout--) == 0) return -1;
  }
	
	// 起始位
	I2C_GenerateSTART(I2C1, ENABLE);
	
	// 测试 EV5 事件并清除它
	sEETimeout = sEE_FLAG_TIMEOUT;
  while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_MODE_SELECT))
  {
    if((sEETimeout--) == 0) return -1;
  }
	
	// 总线寻址 24C02
	I2C_Send7bitAddress(I2C1, I2C_24C02_Address, I2C_Direction_Transmitter);
	
	// 测试 EV6 事件并清除它
	sEETimeout = sEE_FLAG_TIMEOUT;
  while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED))
  {
    if((sEETimeout--) == 0) return -1;
  } 
	
	// 24C02 片内寻址写
	I2C_SendData(I2C1, addr);
	
	// 测试 EV8 事件并清除它
	sEETimeout = sEE_FLAG_TIMEOUT;
  while(I2C_GetFlagStatus(I2C1, I2C_FLAG_BTF) == RESET)
  {
    if((sEETimeout--) == 0) return -1;
  }
	
	// 重复起始位
	I2C_GenerateSTART(I2C1, ENABLE);
	
	// 测试 EV5 事件并清除它
	sEETimeout = sEE_FLAG_TIMEOUT;
  while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_MODE_SELECT))
  {
    if((sEETimeout--) == 0) return -1;
  }
	
	// 24C02 片内寻址读
	I2C_Send7bitAddress(I2C1, I2C_24C02_Address, I2C_Direction_Receiver); 
	
	// 等待地址标志置位(此时地址标志还未清除)
	sEETimeout = sEE_FLAG_TIMEOUT;
	while(I2C_GetFlagStatus(I2C1, I2C_FLAG_ADDR) == RESET)
	{
		if((sEETimeout--) == 0) return -1;
	}   
	
	// 通过读 SR1 和 SR2 寄存器来清除地址标志(SR1 已读过)
	(void) I2C1->SR2;
	
	// 开始读取 size - 1 个字节数据
	for (i = 0; i < size - 1; i++)
	{
		// 等待可读
		sEETimeout = sEE_FLAG_TIMEOUT;
		while(I2C_GetFlagStatus(I2C1, I2C_FLAG_RXNE) == RESET)
		{
			if((sEETimeout--) == 0) return i;
		}
		
		// 读取数据
		buf[i] = I2C_ReceiveData(I2C1);
		
		// 应答
		I2C_AcknowledgeConfig(I2C1, ENABLE); 
	}
	
	// 禁用应答
	I2C_AcknowledgeConfig(I2C1, DISABLE); 
	
	// 停止位
	I2C_GenerateSTOP(I2C1, ENABLE);
	
	// 等待可读
	sEETimeout = sEE_FLAG_TIMEOUT;
	while(I2C_GetFlagStatus(I2C1, I2C_FLAG_RXNE) == RESET)
	{
		if((sEETimeout--) == 0) return i;
	}
		
	// 读取最后一个数据
	buf[i] = I2C_ReceiveData(I2C1);
	
	// 等待停止位被清除
	sEETimeout = sEE_FLAG_TIMEOUT;
	while(I2C1->CR1 & I2C_CR1_STOP)
	{
		if((sEETimeout--) == 0) return -1;
	}  
	
	// 重新使能应答，准备下一次读
	I2C_AcknowledgeConfig(I2C1, ENABLE);  

	return size;
}

/**
 * 功能：  将 buf 中的 size 个字节写入 24C02 的 addr 开始处
 * 参数：  buf  要写入的数据缓冲区
 *         addr 24C02 内存地址
 *         size 要写入的字节数
 * 返回值：返回成功写入的字节数
 **/
int I2C1_24c02_WriteBuffer(uint8_t *buf, uint8_t addr, uint8_t size)
{
	int i;
	
	// 避免超出 24C02 的内存范围
	if (addr + size > M24C02_CAP)
	{
		size = M24C02_CAP - addr;
	}
	
	// 一个一个写入
	for (i = 0; i < size; i++)
	{
		if (-1 == I2C1_24c02_write_byte(addr + i, buf[i]))
		{
			break;
		}
	}
	
	return i;
}


// 作业：1. 写一批数据到 24C02 指定地址
//       2. 从 24C02 读一个字节数据
//       3. 从 24C02 读一批数据（可以封闭 2. 或实现顺序读）




