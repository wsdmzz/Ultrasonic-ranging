
#ifndef _I2C_H_
#define _I2C_H_

#include "stm32f4xx.h"

#define I2C_OwnAddress 0xB0
#define I2C_24C02_Address 0xA0
#define M24C02_CAP 256

/**
 * 功能：  初始化 I2C1
 * 参数：  无
 * 返回值：无
 **/
void I2C1_init(void);

/**
 * 功能：  I2C1 写入 24C02 EEPROM 一个字节数据
 * 参数：  addr 24C02 内偏移地址
 *         data 要写入的一字节数据
 * 返回值：成功返回 0，失败返回 -1
 **/
int I2C1_24c02_write_byte(uint8_t addr, uint8_t data);

/**
 * 功能：  从 24C02 的 addr 处读取最多 size 个字节到 buf 中
 * 参数：  buf  存放读取的数据缓冲区
 *         addr 24C02 内读取的超始地址
 *         size 要读取的字节数
 * 返回值：成功返回实际读取的字节数，失败返回 -1
 **/
int I2C1_24c02_ReadBuffer(uint8_t* buf, uint8_t addr, uint8_t size);

/**
 * 功能：  将 buf 中的 size 个字节写入 24C02 的 addr 开始处
 * 参数：  buf  要写入的数据缓冲区
 *         addr 24C02 内存地址
 *         size 要写入的字节数
 * 返回值：返回成功写入的字节数
 **/
int I2C1_24c02_WriteBuffer(uint8_t *buf, uint8_t addr, uint8_t size);

#endif
