#include "iwdg.h"

#if 0

/* Prescaler and Counter configuration functions ******************************/
void IWDG_WriteAccessCmd(uint16_t IWDG_WriteAccess);
void IWDG_SetPrescaler(uint8_t IWDG_Prescaler);
void IWDG_SetReload(uint16_t Reload);
void IWDG_ReloadCounter(void);

/* IWDG activation function ***************************************************/
void IWDG_Enable(void);

/* Flag management function ***************************************************/
FlagStatus IWDG_GetFlagStatus(uint16_t IWDG_FLAG);

#endif

/**
 * 功能：  初始化独立看门狗
 * 参数：  prescale 预分频值：
 *             IWDG_Prescaler_4
 *             IWDG_Prescaler_8
 *             IWDG_Prescaler_16
 *             IWDG_Prescaler_32
 *             IWDG_Prescaler_64
 *             IWDG_Prescaler_128
 *             IWDG_Prescaler_256
 *         reload   预装载值，不超过 12 位的值
 * 返回值：无
 **/
void IWDG_init(uint8_t prescale, uint16_t reload)
{
	// 取消写保护
	IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);
	// 设置预分频器
	IWDG_SetPrescaler(prescale);
	// 设置重载装载值
	IWDG_SetReload(reload);
	// 使能看门狗
	IWDG_Enable();
}

