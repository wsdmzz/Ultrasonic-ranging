#ifndef _IWDG_H_
#define _IWDG_H_

#include "stm32f4xx.h"

/**
 * 功能：  初始化独立看门狗
 * 参数：  prescale 预分频值：
 *             IWDG_Prescaler_4
 *             IWDG_Prescaler_8
 *             IWDG_Prescaler_16
 *             IWDG_Prescaler_32
 *             IWDG_Prescaler_64
 *             IWDG_Prescaler_128
 *             IWDG_Prescaler_256
 *         reload   预装载值，不超过 12 位的值
 * 返回值：无
 **/
void IWDG_init(uint8_t prescale, uint16_t reload);

#endif
