#include "key-exti.h"
#include "stm32f4xx.h"
#include "key.h"
#include "key-exti.h"
#include "delay.h"
#include "led.h"

/**
 * 功能：  初始化按键（外部中断方式）
 * 参数：  无
 * 返回值：无
 **/
void KEY_exti_init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	EXTI_InitTypeDef EXTI_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	// 使能 GPIOA, GPIOE 时钟
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA | RCC_AHB1Periph_GPIOE, ENABLE);

	// 配置 PA0
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;  // 通用输入
	// 输出类型和输出速度是在通用输出模式或复用功能时才要配置
	//GPIO_InitStructure.GPIO_OType = ?;
	//GPIO_InitStructure.GPIO_Speed = ?; 
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;     // PA0
	// 内部弱上拉/下拉是在外部浮空时才起作用
	// 否则是由外部上拉/下拉决定
	// 此处上拉/下拉可以不配置，即可以浮空
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;   // 上拉
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	// 配置 PE2, PE3, PE4
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2 | GPIO_Pin_3 
	| GPIO_Pin_4;     // PE2, PE3, PE4
	GPIO_Init(GPIOE, &GPIO_InitStructure);
	
	// 由于要使用 SYSCFG 进行外部中断的配置，因此需要使能其时钟
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);
	// 设置IO口与中断线的映射关系
	SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOA, EXTI_PinSource0);
	SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOE, EXTI_PinSource2);
	SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOE, EXTI_PinSource3);
	SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOE, EXTI_PinSource4);
	// SYSCFG 配置完成后可以关闭其时钟(省电)，也可以不关闭(不省电)
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, DISABLE);
	
	// 使能外部中断时钟
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_EXTIT, ENABLE);
	
	// 初始化外部中断
	EXTI_InitStructure.EXTI_Line = EXTI_Line0 | EXTI_Line2 |
		EXTI_Line3 | EXTI_Line4;
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	// 配置模式为中断模式，中断模式是由软件处理，
	// 而事件模式则由硬件处理(由脉冲电路产生脉冲)
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	// 配置为下降沿触发中断，这样在按下按键时产生中断
	// 如果是配置为上升沿，则是在按键松开时产生中断
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
	EXTI_Init(&EXTI_InitStructure);
	
	// NVIC 对于 EXTI0, EXTI2, EXTI3, EXTI4 的配置
	NVIC_InitStructure.NVIC_IRQChannel = EXTI0_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
	NVIC_Init(&NVIC_InitStructure);
	
	NVIC_InitStructure.NVIC_IRQChannel = EXTI2_IRQn;
	NVIC_Init(&NVIC_InitStructure);
	
	NVIC_InitStructure.NVIC_IRQChannel = EXTI3_IRQn;
	NVIC_Init(&NVIC_InitStructure);
	
	NVIC_InitStructure.NVIC_IRQChannel = EXTI4_IRQn;
	NVIC_Init(&NVIC_InitStructure);
	
	// 清除各中断线标志
	EXTI_ClearITPendingBit(EXTI_Line0);
	EXTI_ClearITPendingBit(EXTI_Line2);
	EXTI_ClearITPendingBit(EXTI_Line3);
	EXTI_ClearITPendingBit(EXTI_Line4);
}

volatile int key_value = 0xF;

// 外部中断线 0 的中断处理程序
void EXTI0_IRQHandler(void)
{
	// 此函数是用于 EXTI9_5_IRQHandler 中判断哪个中断线上的中断
	// 对于 EXTI0_IRQHandler 没有用处，它不能判断是哪一组 IO
	//EXTI_GetITStatus(EXTI_Line0);
	
	// 要判断按键 0 是否按下，还得直接判断 GPIOA0 的数据输入寄存器
	if (key_status(KEY0) == KEY_DOWN)
	{
		int i, j;
		
		key_value &= ~(1 << 0);
		// 延时去抖
		for (i = 0; i < 1000; i++)
			for (j = 0; j < 10000; j++);
		// 清除 EXTI0 中断标志
		EXTI_ClearITPendingBit(EXTI_Line0);
	}
}

// 外部中断线 2 的中断处理程序
void EXTI2_IRQHandler(void)
{
	// 此函数是用于 EXTI9_5_IRQHandler 中判断哪个中断线上的中断
	// 对于 EXTI0_IRQHandler 没有用处，它不能判断是哪一组 IO
	//EXTI_GetITStatus(EXTI_Line0);
	
	// 要判断按键 1 是否按下，还得直接判断 GPIOA0 的数据输入寄存器
	if (key_status(KEY1) == KEY_DOWN)
	{
		int i, j;
		
		key_value &= ~(1 << 1);
		// 延时去抖
		for (i = 0; i < 1000; i++)
			for (j = 0; j < 10000; j++);
		// 清除 EXTI2 中断标志
		EXTI_ClearITPendingBit(EXTI_Line2);
	}
}

// 外部中断线 3 的中断处理程序
void EXTI3_IRQHandler(void)
{
	// 此函数是用于 EXTI9_5_IRQHandler 中判断哪个中断线上的中断
	// 对于 EXTI0_IRQHandler 没有用处，它不能判断是哪一组 IO
	//EXTI_GetITStatus(EXTI_Line0);
	
	// 要判断按键 2 是否按下，还得直接判断 GPIOA0 的数据输入寄存器
	if (key_status(KEY2) == KEY_DOWN)
	{
		int i, j;
		
		key_value &= ~(1 << 2);
		// 延时去抖
		for (i = 0; i < 1000; i++)
			for (j = 0; j < 10000; j++);
		// 清除 EXTI3 中断标志
		EXTI_ClearITPendingBit(EXTI_Line3);
	}
}

// 外部中断线 4 的中断处理程序
void EXTI4_IRQHandler(void)
{
	// 此函数是用于 EXTI9_5_IRQHandler 中判断哪个中断线上的中断
	// 对于 EXTI0_IRQHandler 没有用处，它不能判断是哪一组 IO
	//EXTI_GetITStatus(EXTI_Line0);
	
	// 要判断按键 3 是否按下，还得直接判断 GPIOA0 的数据输入寄存器
	if (key_status(KEY3) == KEY_DOWN)
	{
		int i, j;
		
		key_value &= ~(1 << 3);
		// 延时去抖
		for (i = 0; i < 1000; i++)
			for (j = 0; j < 10000; j++);
		// 清除 EXTI4 中断标志
		EXTI_ClearITPendingBit(EXTI_Line4);
	}
}


/**
 * 功能：  扫描 4 个按键的状态
 * 参数：  无
 * 返回值：每个按键的状态：KEY_UP, KEY_DOWN，
 *         KEY0, KEY1, KEY2, KEY3 分别对应位 0, 1, 2, 3
 **/ 
int keys_exti_scan(void)
{
	int status;
	
	status = key_value;
	key_value = 0xF;
	
	return status;
}

/**
 * 功能：  判断按键 key 是否按下
 * 参数：  statuc 4 个按键的状态
 *         key    哪个按键：KEY0, KEY1, KEY2, KEY3
 * 返回值：按键是否按下：KEY_PRESSED, KEY_NO_PRESSED
 **/
int key_exti_pressed(int status, int key)
{
	// _ _ _ _
	switch (key)
	{
		case KEY0:
			// status: ???? ???? ???? ???? ???? ???? ???? abcd
			// 0x1   : 0000 0000 0000 0000 0000 0000 0000 0001
			return status & 0x1;
		case KEY1:
			// status: ???? ???? ???? ???? ???? ???? ???? abcd
			//         0??? ???? ???? ???? ???? ???? ???? ?abc 
			// 0x1   : 0000 0000 0000 0000 0000 0000 0000 0001
			return (status >> 1) & 0x1;
		case KEY2:
			return (status >> 2) & 0x1;
		case KEY3:
			return (status >> 3) & 0x1;
	}
	
	return KEY_NO_PRESSED;
}
