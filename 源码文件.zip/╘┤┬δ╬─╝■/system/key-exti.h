
#ifndef _KEY_EXTI_H_
#define _KEY_EXTI_H_

/**
 * 功能：  初始化按键（外部中断方式）
 * 参数：  无
 * 返回值：无
 **/
void KEY_exti_init(void);

/**
 * 功能：  扫描 4 个按键的状态
 * 参数：  无
 * 返回值：每个按键的状态：KEY_UP, KEY_DOWN，
 *         KEY0, KEY1, KEY2, KEY3 分别对应位 0, 1, 2, 3
 **/ 
int keys_exti_scan(void);

/**
 * 功能：  判断按键 key 是否按下
 * 参数：  statuc 4 个按键的状态
 *         key    哪个按键：KEY0, KEY1, KEY2, KEY3
 * 返回值：按键是否按下：KEY_PRESSED, KEY_NO_PRESSED
 **/
int key_exti_pressed(int status, int key);

#endif
