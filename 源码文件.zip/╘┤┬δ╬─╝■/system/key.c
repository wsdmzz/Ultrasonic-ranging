
#include "key.h"
#include "delay.h"

/*
	KEY0  -- PA0
	KEY1  -- PE2
	KEY2  -- PE3
	KEY3  -- PE4
	对信号的值的获取转换为对引脚对应输入数据寄存器位的读取
*/

/**
 * 功能：  初始化按键（轮询方式）
 * 参数：  无
 * 返回值：无
 **/
void KEY_init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;

	// 使能 GPIOA, GPIOE 时钟
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA | RCC_AHB1Periph_GPIOE, ENABLE);

	// 配置 PA0
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;  // 通用输入
	// 输出类型和输出速度是在通用输出模式或复用功能时才要配置
	//GPIO_InitStruct.GPIO_OType = ?;
	//GPIO_InitStruct.GPIO_Speed = ?; 
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_0;     // PA0
	// 内部弱上拉/下拉是在外部浮空时才起作用
	// 否则是由外部上拉/下拉决定
	// 此处上拉/下拉可以不配置，即可以浮空
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;   // 上拉
	GPIO_Init(GPIOA, &GPIO_InitStruct);

	// 配置 PE2, PE3, PE4
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_2 | GPIO_Pin_3 
	| GPIO_Pin_4;     // PE2, PE3, PE4
	GPIO_Init(GPIOE, &GPIO_InitStruct);
}
 
/**
 * 功能：  获取 key 的状态
 * 参数：  key 哪一个按键：KEY0, KEY1, KEY2, KEY3
 * 返回值：按键 key 的状态：KEY_UP, KEY_DOWN
 **/
int key_status(int key)
{
	// uint8_t GPIO_ReadInputDataBit(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin);
	switch (key)
	{
		case KEY0:
			return GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0)
				? KEY_UP : KEY_DOWN;
		case KEY1:
			return GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_2)
				? KEY_UP : KEY_DOWN;
		case KEY2:
			return GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_3)
				? KEY_UP : KEY_DOWN;
		case KEY3:
			return GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_4)
				? KEY_UP : KEY_DOWN;
	}
	
	return KEY_UP;
}

/**
 * 功能：  扫描 4 个按键的状态
 * 参数：  无
 * 返回值：每个按键的状态：KEY_UP, KEY_DOWN，
 *         KEY0, KEY1, KEY2, KEY3 分别对应位 0, 1, 2, 3
 **/ 
int keys_scan(void)
{
	int status1 = 0, status2 = 0;
	
	status1 = key_status(KEY0) | (key_status(KEY1) << 1)
		| (key_status(KEY2) << 2) | (key_status(KEY3) << 3);
	// 延时去抖
	Delay(1);
	status2 = key_status(KEY0) | (key_status(KEY1) << 1)
		| (key_status(KEY2) << 2) | (key_status(KEY3) << 3);
	
	return status1 | status2;
}

/**
 * 功能：  判断按键 key 是否按下
 * 参数：  statuc 4 个按键的状态
 *         key    哪个按键：KEY0, KEY1, KEY2, KEY3
 * 返回值：按键是否按下：KEY_PRESSED, KEY_NO_PRESSED
 **/
int key_pressed(int status, int key)
{
	// _ _ _ _
	switch (key)
	{
		case KEY0:
			// status: ???? ???? ???? ???? ???? ???? ???? abcd
			// 0x1   : 0000 0000 0000 0000 0000 0000 0000 0001
			return status & 0x1;
		case KEY1:
			// status: ???? ???? ???? ???? ???? ???? ???? abcd
			//         0??? ???? ???? ???? ???? ???? ???? ?abc 
			// 0x1   : 0000 0000 0000 0000 0000 0000 0000 0001
			return (status >> 1) & 0x1;
		case KEY2:
			return (status >> 2) & 0x1;
		case KEY3:
			return (status >> 3) & 0x1;
	}
	
	return KEY_NO_PRESSED;
}


