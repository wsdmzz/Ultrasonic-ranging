
#ifndef _KEY_H_
#define _KEY_H_

#include "stm32f4xx.h"

#define KEY0 0
#define KEY1 1
#define KEY2 2
#define KEY3 3

#define KEY_DOWN 0
#define KEY_UP 1

#define KEY_PRESSED 0
#define KEY_NO_PRESSED 1

/**
 * 功能：  初始化按键（轮询方式）
 * 参数：  无
 * 返回值：无
 **/
 void KEY_init(void);
 
/**
 * 功能：  获取 key 的状态
 * 参数：  key 哪一个按键：KEY0, KEY1, KEY2, KEY3
 * 返回值：按键 key 的状态：KEY_UP, KEY_DOWN
 **/
int key_status(int key);

/**
 * 功能：  扫描 4 个按键的状态
 * 参数：  无
 * 返回值：每个按键的状态：KEY_UP, KEY_DOWN，
 *         KEY0, KEY1, KEY2, KEY3 分别对应位 0, 1, 2, 3
 **/ 
int keys_scan(void);

/**
 * 功能：  判断按键 key 是否按下
 * 参数：  statuc 4 个按键的状态
 *         key    哪个按键：KEY0, KEY1, KEY2, KEY3
 * 返回值：按键是否按下：KEY_PRESSED, KEY_NO_PRESSED
 **/
int key_pressed(int status, int key);

#endif
