
#include "led.h"
#include "delay.h"

/*
   LED0            -- PF9
	 LED1            -- PF10
	 FSMC_D10(LED2)  -- PE13
	 FSMC_D11(LED3)  -- PE14
	 对 LED 的控制转换为对 GPIOE13, GPIOE14, GPIOF9 和 GPIOF10 的控制
 */

/**
 * 功能：  初始化 LED
 * 参数：  无
 * 返回值：无
 **/
void LED_init(void)
{
	/*
	外设工作必须使能时钟，而默认情况下外设时钟是禁用的，
	因此必须使能外设时钟。
	经查手册《第 2 章 存储器和总线架构》的《2.3 存储器映射》
	的《表 2. STM32F4xx 寄存器边界地址》得知，GPIOE 和 GPIOF
	都是在 AHB1 总线上。
	查《第 6 章 复位和时钟控制 (RCC)》的《6.3.12 RCC AHB1 
	外设时钟使能寄存器 (RCC_AHB1ENR)》得知 GPIOE 和 GPIOF 
	的时钟使能由 [5:4] 位控制，置 1 使能，清 0 禁用。
	*/
	// 同时使能 GPIOE 和 GPIOF 时钟(通过函数实现)
	//RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE | 
	//	RCC_AHB1Periph_GPIOF, ENABLE);
	// 同时使能 GPIOE 和 GPIOF 时钟(通过原始方式实现)
	RCC_AHB1ENR |= 0x3 << 4;
	
	// 1. 配置 LED 0 和 LED 1 
	// 模式为“通用输出模式”
	GPIOF_MODER &= ~(0xF << 18);   // 清 0 [21:18] 位
	GPIOF_MODER |= 0x5 << 18;      // [21:18] 位设置为 0101
	// 输出类型为“输出推挽”
	GPIOF_OTYPER &= ~(0x3 << 9);  // 清 0 [10:9] 位
	// 输出速度为“100MHz”
	GPIOF_OSPEEDR |= 0xF << 18;    // [21:18] 位设置为 1111
	// 上拉
	GPIOF_PUPDR &= ~(0xF << 18);   // 清 0 [21:18] 位
	GPIOF_PUPDR |= 0x5 << 18;      // [21:18] 位设置为 0101
	// 通过对 GPIOF_ODR[10:9] 进行清 0 则点亮 LED 0 和 LED 1,
	// 置 1 则熄灭 LED 0 和 LED 1
	// 也可以通过 GPIOF_BSRR[26:25] 置 1 则点亮 LED 0 和 LED 1,
	// GPIOF_BSRR[10:9] 置 1 则熄灭 LED 0 和 LED 1
	// GPIOF_AFRL 和 GPIOF_AFRH 因为没有使用,不需配置
	
	// 2. 配置 LED 2 和 LED 3 
	// 模式为“通用输出模式”
	GPIOE_MODER &= ~(0xF << 26);   // 清 0 [29:26] 位
	GPIOE_MODER |= 0x5 << 26;      // [29:26] 位设置为 0101
	// 输出类型为“输出推挽”
	GPIOE_OTYPER &= ~(0x3 << 13);  // 清 0 [14:13] 位
	// 输出速度为“100MHz”
	GPIOE_OSPEEDR |= 0xF << 26;    // [29:26] 位设置为 1111
	// 上拉
	GPIOE_PUPDR &= ~(0xF << 26);   // 清 0 [29:26] 位
	GPIOE_PUPDR |= 0x5 << 26;      // [29:26] 位设置为 0101
	// 通过对 GPIOE_ODR[14:13] 进行清 0 则点亮 LED 2 和 LED 3,
	// 置 1 则熄灭 LED 2 和 LED 3
	// 也可以通过 GPIOE_BSRR[30:29] 置 1 则点亮 LED 2 和 LED 3,
	// GPIOE_BSRR[14:13] 置 1 则熄灭 LED 2 和 LED 3
	// GPIOE_AFRL 和 GPIOE_AFRH 因为没有使用,不需配置
	
	// 默认关闭所有 LED
	LED0_OFF();
	LED1_OFF();
	LED2_OFF();
	LED3_OFF();
}

// LED 应用程序
/**
 * 功能：  流水灯
 * 参数：  interval 时间间隔(单位：10ms)
 * 返回值：无
 **/
void liushuideng1(int interval)
{
	// LED0 点亮，其余熄灭
	LED0_ON();
	LED1_OFF();
	LED2_OFF();
	LED3_OFF();
	Delay(interval);
	
	// LED1 点亮，其余熄灭
	LED0_OFF();
	LED1_ON();
	LED2_OFF();
	LED3_OFF();
	Delay(interval);
	
	// LED2 点亮，其余熄灭
	LED0_OFF();
	LED1_OFF();
	LED2_ON();
	LED3_OFF();
	Delay(interval);
	
	// LED3 点亮，其余熄灭
	LED0_OFF();
	LED1_OFF();
	LED2_OFF();
	LED3_ON();
	Delay(interval);
}

/**
 * 功能：  流水灯
 * 参数：  interval 时间间隔(单位：10ms)
 * 返回值：无
 **/
void liushuideng2(int interval)
{
	// LED0, LED3 点亮，其余熄灭
	LED0_ON();
	LED1_OFF();
	LED2_OFF();
	LED3_ON();
	Delay(interval);
	
	// LED1, LED2 点亮，其余熄灭
	LED0_OFF();
	LED1_ON();
	LED2_ON();
	LED3_OFF();
	Delay(interval);
}

/**
 * 功能：  一个灯的流水灯
 * 参数：  timer 定时器
 *         which 哪一个灯：LED0, LED1, LED2, LED3
 * 返回值：无
 **/
void liushuideng3(struct timer *timer, int which)
{
	if (timer->turn == TURN_ON)
	{
		switch (which)
		{
			case LED0: LED0_ON(); break;
			case LED1: LED1_ON(); break;
			case LED2: LED2_ON(); break;
			case LED3: LED3_ON(); break;
		}
		timer->on--;
		if (timer->on == 0)
		{
			timer->on = timer->on_intv;
			timer->turn = TURN_OFF;
		}
	}
	else if (timer->turn == TURN_OFF)
	{
		switch (which)
		{
			case LED0: LED0_OFF(); break;
			case LED1: LED1_OFF(); break;
			case LED2: LED2_OFF(); break;
			case LED3: LED3_OFF(); break;
		}
		timer->off--;
		if (timer->off == 0)
		{
			timer->off = timer->off_intv;
			timer->turn = TURN_ON;
			timer->count--;
		}
	}
	Delay(1);
}

struct timer timers0[] = {
{10, 10, 10, 10, TURN_ON, 20}, {15, 15, 15, 15, TURN_ON, 15}, 
{20, 20, 20, 20, TURN_ON, 10}, {25, 25, 25, 25, TURN_ON, 8}, 
{30, 30, 30, 30, TURN_ON, 5}};

struct timer timers1[] = {
{50, 50, 50, 50, TURN_ON, 2}, {40, 40, 40, 40, TURN_ON, 4}, 
{30, 30, 30, 30, TURN_ON, 8}, {20, 20, 20, 20, TURN_ON, 16}, 
{10, 10, 10, 10, TURN_ON, 32}, {5, 5, 5, 5, TURN_ON, 64}};

struct timer timers2[] = {{25, 25, 25, 25, TURN_ON, 1}};

struct timer timers3[] = {{10, 10, 10, 10, TURN_ON, 1}};

int i0 = 0, i1 = 0, i2 = 0, i3 = 0;
int dir0 = 1, dir1 = 1, dir2 = 1, dir3 = 1;
struct timer timer0, timer1, timer2, timer3;

#define LENGTHOF(arr) ((sizeof (arr)) / (sizeof ((arr)[0])))
/*
void update_timer(struct timer *timer, )
{
	
}
*/

/**
 * 功能：  流水灯
 * 参数：  无
 * 返回值：无
 **/
void liushuideng4(void)
{
	if (timer0.count == 0)
	{
		timer0 = timers0[i0];
		if (dir0 == 1)
		{
			i0++;
		}
		else
		{
			i0--;
		}
		if (i0 == LENGTHOF(timers0))
		{
			dir0 = 0;
		}
		if (i0 == -1)
		{
			dir0 = 1;
		}
	}
	if (timer1.count == 0)
	{
		timer1 = timers1[i1];
		if (dir1 == 1)
		{
			i1++;
		}
		else
		{
			i1--;
		}
		if (i1 == LENGTHOF(timers1))
		{
			dir1 = 0;
		}
		if (i1 == -1)
		{
			dir1 = 1;
		}
	}
	if (timer2.count == 0)
	{
		timer2 = timers2[i2];
		if (dir2 == 1)
		{
			i2++;
		}
		else
		{
			i2--;
		}
		if (i2 == LENGTHOF(timers2))
		{
			dir2 = 0;
		}
		if (i2 == -1)
		{
			dir2 = 1;
		}
	}
	if (timer3.count == 0)
	{
		timer3 = timers3[i3];
		if (dir3 == 1)
		{
			i3++;
		}
		else
		{
			i3--;
		}
		if (i3 == LENGTHOF(timers3))
		{
			dir3 = 0;
		}
		if (i3 == -1)
		{
			dir3 = 1;
		}
	}
	liushuideng3(&timer0, LED0);
	liushuideng3(&timer1, LED3);
	//liushuideng3(&timer2, LED2);
	//liushuideng3(&timer3, LED3);
}

