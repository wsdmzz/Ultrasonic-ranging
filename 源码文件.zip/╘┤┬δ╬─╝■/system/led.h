
#ifndef _LED_H_
#define _LED_H_

#include "stm32f4xx.h"
#include "bit_bauding.h"

// GPIOE 和 GPIOF 寄存器
#define GPIOE_MODER   (*(volatile uint32_t *)(GPIOE_BASE + 0x00))
#define GPIOE_OTYPER  (*(volatile uint32_t *)(GPIOE_BASE + 0x04))
#define GPIOE_OSPEEDR (*(volatile uint32_t *)(GPIOE_BASE + 0x08))
#define GPIOE_PUPDR   (*(volatile uint32_t *)(GPIOE_BASE + 0x0C))
#define GPIOE_IDR     (*(volatile uint32_t *)(GPIOE_BASE + 0x10))
#define GPIOE_ODR     (*(volatile uint32_t *)(GPIOE_BASE + 0x14))
#define GPIOE_BSRR    (*(volatile uint32_t *)(GPIOE_BASE + 0x18))
#define GPIOE_LCKR    (*(volatile uint32_t *)(GPIOE_BASE + 0x1C))
#define GPIOE_AFRL    (*(volatile uint32_t *)(GPIOE_BASE + 0x20))
#define GPIOE_AFRH    (*(volatile uint32_t *)(GPIOE_BASE + 0x24))

#define GPIOF_MODER   (*(volatile uint32_t *)(GPIOF_BASE + 0x00))
#define GPIOF_OTYPER  (*(volatile uint32_t *)(GPIOF_BASE + 0x04))
#define GPIOF_OSPEEDR (*(volatile uint32_t *)(GPIOF_BASE + 0x08))
#define GPIOF_PUPDR   (*(volatile uint32_t *)(GPIOF_BASE + 0x0C))
#define GPIOF_IDR     (*(volatile uint32_t *)(GPIOF_BASE + 0x10))
#define GPIOF_ODR     (*(volatile uint32_t *)(GPIOF_BASE + 0x14))
#define GPIOF_BSRR    (*(volatile uint32_t *)(GPIOF_BASE + 0x18))
#define GPIOF_LCKR    (*(volatile uint32_t *)(GPIOF_BASE + 0x1C))
#define GPIOF_AFRL    (*(volatile uint32_t *)(GPIOF_BASE + 0x20))
#define GPIOF_AFRH    (*(volatile uint32_t *)(GPIOF_BASE + 0x24))

#if 0	

// 直接操作输出数据寄存器实现点灯/灭灯
// 定义点灯/灭灯的宏
#define LED0_OFF() do { GPIOF_ODR |= 1 << 9; } while (0)
#define LED1_OFF() do { GPIOF_ODR |= 1 << 10; } while (0)
#define LED2_OFF() do { GPIOE_ODR |= 1 << 13; } while (0)
#define LED3_OFF() do { GPIOE_ODR |= 1 << 14; } while (0)

#define LED0_ON()  do { GPIOF_ODR &= ~(1 << 9); } while (0)
#define LED1_ON()  do { GPIOF_ODR &= ~(1 << 10); } while (0)
#define LED2_ON()  do { GPIOE_ODR &= ~(1 << 13); } while (0)
#define LED3_ON()  do { GPIOE_ODR &= ~(1 << 14); } while (0)

#endif

// 通过操作复位/置位寄存器实现点灯/灭灯
#define LED0_OFF() do { GPIOF_BSRR |= 1 << 9; } while (0)
#define LED1_OFF() do { GPIOF_BSRR |= 1 << 10; } while (0)
#define LED2_OFF() do { GPIOE_BSRR |= 1 << 13; } while (0)
#define LED3_OFF() do { GPIOE_BSRR |= 1 << 14; } while (0)

#define LED0_ON() do { GPIOF_BSRR |= 1 << 25; } while (0)
#define LED1_ON() do { GPIOF_BSRR |= 1 << 26; } while (0)
#define LED2_ON() do { GPIOE_BSRR |= 1 << 29; } while (0)
#define LED3_ON() do { GPIOE_BSRR |= 1 << 30; } while (0)

// 使用位段定义引脚，可以直接对这些引脚置 1 或清 0
#define PF9  (*(volatile uint32_t *)(BIT_WORD_ADDR(0x42000000, 0x00021414, 9)))
#define PF10 (*(volatile uint32_t *)(BIT_WORD_ADDR(0x42000000, 0x00021414, 10)))
#define PE13 (*(volatile uint32_t *)(BIT_WORD_ADDR(0x42000000, 0x00021014, 13)))
#define PE14 (*(volatile uint32_t *)(BIT_WORD_ADDR(0x42000000, 0x00021014, 14)))
			
// RCC_AHB1ENR 寄存器 
#define RCC_AHB1ENR (*(volatile uint32_t *)(RCC_BASE + 0x30))

#define LED0  0
#define LED1  1
#define LED2  2
#define LED3  3

#define TURN_OFF 0
#define TURN_ON  1

// 定时器
struct timer
{
	int on_intv;
	int on;
	int off_intv;
	int off;
	int turn;    // TURN_ON, TURN_OFF
	int count;
};

/**
 * 功能：  初始化 LED
 * 参数：  无
 * 返回值：无
 **/
void LED_init(void);

/**
 * 功能：  流水灯
 * 参数：  interval 时间间隔(单位：10ms)
 * 返回值：无
 **/
void liushuideng1(int interval);

/**
 * 功能：  流水灯
 * 参数：  interval 时间间隔(单位：10ms)
 * 返回值：无
 **/
void liushuideng2(int interval);

/**
 * 功能：  一个灯的流水灯
 * 参数：  timer 定时器
 *         which 哪一个灯：LED0, LED1, LED2, LED3
 * 返回值：无
 **/
void liushuideng3(struct timer *timer, int which);

/**
 * 功能：  流水灯
 * 参数：  无
 * 返回值：无
 **/
void liushuideng4(void);

#endif
