
#include "led2.h"

#if 0
typedef struct
{
  __IO uint32_t MODER;    /*!< GPIO port mode register,               Address offset: 0x00      */
  __IO uint32_t OTYPER;   /*!< GPIO port output type register,        Address offset: 0x04      */
  __IO uint32_t OSPEEDR;  /*!< GPIO port output speed register,       Address offset: 0x08      */
  __IO uint32_t PUPDR;    /*!< GPIO port pull-up/pull-down register,  Address offset: 0x0C      */
  __IO uint32_t IDR;      /*!< GPIO port input data register,         Address offset: 0x10      */
  __IO uint32_t ODR;      /*!< GPIO port output data register,        Address offset: 0x14      */
  __IO uint16_t BSRRL;    /*!< GPIO port bit set/reset low register,  Address offset: 0x18      */
  __IO uint16_t BSRRH;    /*!< GPIO port bit set/reset high register, Address offset: 0x1A      */
  __IO uint32_t LCKR;     /*!< GPIO port configuration lock register, Address offset: 0x1C      */
  __IO uint32_t AFR[2];   /*!< GPIO alternate function registers,     Address offset: 0x20-0x24 */
} GPIO_TypeDef;
#define GPIOE               ((GPIO_TypeDef *) GPIOE_BASE)
// GPIOE_BASE 0x40021400

// 注意，要理解通过结构体成员访问外设的寄存器
#endif

/**
 * 功能：  初始化 LED(使用结构体方式)
 * 参数：  无
 * 返回值：无
 **/
void LED_init2(void)
{
	// 使能 GPIOE 和 GPIOF 时钟
	RCC->AHB1ENR |= 0x3 << 4;
	
	// 配置 GPIOE 和 GPIOF 寄存器
	GPIOE->MODER &= ~(0xF << 26);
	GPIOE->MODER |= 0x5 << 26;    
	GPIOE->OTYPER &= ~(0x3 << 13);
	GPIOE->OSPEEDR |= 0xF << 26;
	GPIOE->PUPDR &= ~(0xF << 26);
	GPIOE->PUPDR |= 0x5 << 26;
	
	GPIOF->MODER &= ~(0xF << 18);
	GPIOF->MODER |= 0x5 << 18;    
	GPIOF->OTYPER &= ~(0x3 << 9);
	GPIOF->OSPEEDR |= 0xF << 18;
	GPIOF->PUPDR &= ~(0xF << 18);
	GPIOF->PUPDR |= 0x5 << 18;
	
	LED2_0_OFF();
	LED2_1_OFF();
	LED2_2_OFF();
	LED2_3_OFF();
}
