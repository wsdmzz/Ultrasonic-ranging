#ifndef _LED2_H_
#define _LED2_H_

#include "stm32f4xx.h"

#define LED2_0_OFF() do { GPIOF->ODR |= (0x1 << 9); } while (0)
#define LED2_1_OFF() do { GPIOF->ODR |= (0x1 << 10); } while (0)
#define LED2_2_OFF() do { GPIOE->ODR |= (0x1 << 13); } while (0)
#define LED2_3_OFF() do { GPIOE->ODR |= (0x1 << 14); } while (0)

#define LED2_0_ON() do { GPIOF->ODR &= ~(0x1 << 9); } while (0)
#define LED2_1_ON() do { GPIOF->ODR &= ~(0x1 << 10); } while (0)
#define LED2_2_ON() do { GPIOE->ODR &= ~(0x1 << 13); } while (0)
#define LED2_3_ON() do { GPIOE->ODR &= ~(0x1 << 14); } while (0)


/**
 * 功能：  初始化 LED(使用结构体方式)
 * 参数：  无
 * 返回值：无
 **/
void LED_init2(void);

#endif
