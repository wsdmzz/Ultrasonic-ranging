
#include "stm32f4xx.h"
#include "led3.h"

/**
 * 功能：  初始化 LED(使用库函数方式)
 * 参数：  无
 * 返回值：无
 **/
void LED_init3(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	
	// 使能 GPIOE 和 GPIOF 的时钟
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE 
		| RCC_AHB1Periph_GPIOF,	ENABLE);
	
	// 初始化 GPIOE 和 GPIOF
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;    // 输出
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;   // 推挽
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_13 | GPIO_Pin_14;
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;     // 上拉
	GPIO_InitStruct.GPIO_Speed = GPIO_High_Speed; // 100MHz
	GPIO_Init(GPIOE, &GPIO_InitStruct);
	
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_9 | GPIO_Pin_10;
	GPIO_Init(GPIOF, &GPIO_InitStruct);
	
	LED3_0_OFF();
	LED3_1_OFF();
	LED3_2_OFF();
	LED3_3_OFF();
}
