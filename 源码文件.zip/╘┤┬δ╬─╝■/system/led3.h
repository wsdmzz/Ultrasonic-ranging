
#ifndef _LED3_H_
#define _LED3_H_

#include "stm32f4xx.h"
#include "bit_bauding.h"

// void GPIO_SetBits(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin);
#define LED3_0_OFF() do { GPIO_SetBits(GPIOF, GPIO_Pin_9); } while (0)
#define LED3_1_OFF() do { GPIO_SetBits(GPIOF, GPIO_Pin_10); } while (0)
#define LED3_2_OFF() do { GPIO_SetBits(GPIOE, GPIO_Pin_13); } while (0)
#define LED3_3_OFF() do { GPIO_SetBits(GPIOE, GPIO_Pin_14); } while (0)

// void GPIO_ResetBits(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin);
#define LED3_0_ON() do { GPIO_ResetBits(GPIOF, GPIO_Pin_9); } while (0)
#define LED3_1_ON() do { GPIO_ResetBits(GPIOF, GPIO_Pin_10); } while (0)
#define LED3_2_ON() do { GPIO_ResetBits(GPIOE, GPIO_Pin_13); } while (0)
#define LED3_3_ON() do { GPIO_ResetBits(GPIOE, GPIO_Pin_14); } while (0)

#undef LED0
#undef LED1
#undef LED2
#undef LED3

#define LED0  (*(volatile uint32_t *)(BIT_WORD_ADDR(0x42000000, 0x00021414, 9)))
#define LED1  (*(volatile uint32_t *)(BIT_WORD_ADDR(0x42000000, 0x00021414, 10)))
#define LED2  (*(volatile uint32_t *)(BIT_WORD_ADDR(0x42000000, 0x00021014, 13)))
#define LED3  (*(volatile uint32_t *)(BIT_WORD_ADDR(0x42000000, 0x00021014, 14)))

/**
 * 功能：  初始化 LED(使用库函数方式)
 * 参数：  无
 * 返回值：无
 **/
void LED_init3(void);

#endif
