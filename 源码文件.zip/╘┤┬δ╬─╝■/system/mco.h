#ifndef _MCO_H_
#define _MCO_H_

void MCO_init(void);

#endif
