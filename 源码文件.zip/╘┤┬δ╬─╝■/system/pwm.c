#include "pwm.h"
#include "led3.h"

uint16_t PWM_COUNT = 0xFFFF;
uint16_t PWM_PERIOD = 0xFFFF;

/*
	查看原理图得：
	
	LED0  --  PF9/TIM14_CH1/

	因此将 PF9 复用为 TIM14_CH1，配置 TIM14_CH1 为 PWM 输出，
	实现对 LED0 亮度的控制
*/

/**
 * 功能：  初始化 TIM14 为 PWM 输出，从而控制 LED0 亮度
 * 参数：  prescaler  预分频值，范围 [0x0000, 0xFFFF]
 *         pwm_period PWM 计数周期，范围 [0x0000, 0xFFFF]
 *         pwm_count  PWM 计数翻转值
 * 返回值：无
 **/
void TIM14_pwm_led0_init(uint32_t prescaler, uint16_t pwm_period, uint16_t pwm_count)
{
	GPIO_InitTypeDef GPIO_InitTypeStructure;
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	NVIC_InitTypeDef NVIC_InitTypeStructure;
	TIM_OCInitTypeDef TIM_OCInitTypeStructure;
	
	PWM_COUNT &= pwm_count;
	PWM_PERIOD &= pwm_period;
	
	// 使能 GPIOF 和 TIM14 的时钟
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOF, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM14, ENABLE);
	
	// 配置 PF9 复用功能
	GPIO_PinAFConfig(GPIOF, GPIO_PinSource9, GPIO_AF_TIM14);
	
	// 初始化 PF9
	GPIO_InitTypeStructure.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitTypeStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitTypeStructure.GPIO_Pin = GPIO_Pin_9;
	GPIO_InitTypeStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitTypeStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(GPIOF, &GPIO_InitTypeStructure);
	
	// 定时器 TIM14 的时基初始化
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInitStructure.TIM_Period = pwm_period;
	TIM_TimeBaseInitStructure.TIM_Prescaler = prescaler;
	// 以下重复计数值是高级定时器 TIM1 和 TIM8 才使用
	//TIM_TimeBaseInitStructure.TIM_RepetitionCounter = ;
	TIM_TimeBaseInit(TIM14, &TIM_TimeBaseInitStructure);
	
	// 配置 TIM14 的中断
	NVIC_InitTypeStructure.NVIC_IRQChannel = TIM8_TRG_COM_TIM14_IRQn;
	NVIC_InitTypeStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitTypeStructure.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitTypeStructure.NVIC_IRQChannelSubPriority = 2;
	NVIC_Init(&NVIC_InitTypeStructure);
	
	// 清除及使能 TIM14 的更新中断
	TIM_ClearITPendingBit(TIM14, TIM_IT_Update);
	TIM_ITConfig(TIM14, TIM_IT_Update, ENABLE);
	
	// 配置 TIM14 的"输出比较通道1"
	// 以下重复计数值是高级定时器 TIM1 和 TIM8 才使用
	//TIM_OCInitTypeStructure.TIM_OCIdleState = ;
	//TIM_OCInitTypeStructure.TIM_OCNIdleState = ;
	//TIM_OCInitTypeStructure.TIM_OCNPolarity = ;
	//TIM_OCInitTypeStructure.TIM_OutputNState = ;
	TIM_OCInitTypeStructure.TIM_OCMode = TIM_OCMode_PWM1;
	// 输出比较极性，即开始计数时的输出电平高还是低
	TIM_OCInitTypeStructure.TIM_OCPolarity = TIM_OCPolarity_Low;
	TIM_OCInitTypeStructure.TIM_OutputState = TIM_OutputState_Enable;
	TIM_OC1Init(TIM14, &TIM_OCInitTypeStructure);
	
	// 使能预装载寄存器
	TIM_OC1PreloadConfig(TIM14, TIM_OCPreload_Enable);
	// 使能自动重装载的预装载寄存器允许位
	TIM_ARRPreloadConfig(TIM14, ENABLE);
	
	TIM_SetCompare1(TIM14, PWM_COUNT);

	// 使能定时器 TIM14
	TIM_Cmd(TIM14, ENABLE);
}

/*
// 设置占空比
void TIM_SetCompare1(TIM_TypeDef* TIMx, uint32_t Compare1);

void TIM_ITConfig(TIM_TypeDef* TIMx, uint16_t TIM_IT, FunctionalState NewState);
void TIM_GenerateEvent(TIM_TypeDef* TIMx, uint16_t TIM_EventSource);
FlagStatus TIM_GetFlagStatus(TIM_TypeDef* TIMx, uint16_t TIM_FLAG);
void TIM_ClearFlag(TIM_TypeDef* TIMx, uint16_t TIM_FLAG);
ITStatus TIM_GetITStatus(TIM_TypeDef* TIMx, uint16_t TIM_IT);
void TIM_ClearITPendingBit(TIM_TypeDef* TIMx, uint16_t TIM_IT);
void TIM_DMAConfig(TIM_TypeDef* TIMx, uint16_t TIM_DMABase, uint16_t TIM_DMABurstLength);
void TIM_DMACmd(TIM_TypeDef* TIMx, uint16_t TIM_DMASource, FunctionalState NewState);
void TIM_SelectCCDMA(TIM_TypeDef* TIMx, FunctionalState NewState);
*/

int cnt = 0, flg = 1;

// TIM14 中断处理程序
void TIM8_TRG_COM_TIM14_IRQHandler(void)
{
	// 是 TIM14 的更新中断
	if (TIM_GetITStatus(TIM14, TIM_IT_Update))
	{
		TIM_ClearITPendingBit(TIM14, TIM_IT_Update);
		// 一种亮度持续 20 次更新
		if (30 == cnt)
		{
			if (PWM_PERIOD <= PWM_COUNT)
			{
				flg = 0;  // 减递比较值
			}
			if (0 == PWM_COUNT)
			{
				flg = 1;  // 减增比较值
			}
			if (flg)
			{
				PWM_COUNT += 100;
			}
			else
			{
				PWM_COUNT -= 100;
			}
			TIM_SetCompare1(TIM14, PWM_COUNT);
			cnt = 0;
		}
		cnt++;
		LED3_3_ON();
	}
}
