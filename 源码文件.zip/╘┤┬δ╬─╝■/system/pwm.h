#ifndef _PWM_H_
#define _PWM_H_

#include "stm32f4xx.h"

/**
 * 功能：  初始化 TIM14 为 PWM 输出，从而控制 LED0 亮度
 * 参数：  prescaler  预分频值，范围 [0x0000, 0xFFFF]
 *         pwm_period PWM 计数周期，范围 [0x0000, 0xFFFF]
 *         pwm_count  PWM 计数翻转值
 * 返回值：无
 **/
void TIM14_pwm_led0_init(uint32_t prescaler, uint16_t pwm_period, uint16_t pwm_count);

#endif
