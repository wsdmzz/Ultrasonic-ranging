
// TX PA2  ����
// RX PA3  ����

#ifndef _R04_H_
#define _R04_H_


#include "stm32f4xx.h"



void Hcsr04Init();
void hcsr04_NVIC();
void TIM6_IRQHandler(void);
u32 GetEchoTimer(void);
float Hcsr04GetLength(void);
void delay_Ms(uint16_t time);
void delay_Us(uint16_t time);


#endif

