#include "rs485.h"
#include "stdio.h"

/*
	查原理图得知：
	
	RS485_RX -- USART2_TX -- PA2
	RS485_TX -- USART2_RX -- PA3
	RS485_RE -- PG8
	
	RS485_RE 低电平时使能发送，高电平时使能接收
	在 RS485 总线上，一般主机在不发送数据时，就处于接收状态，
	即 RS485_RE 置高电平
	
	在 MCU 内部使用 USART2 收发，而在设备之间则通过 RS485 组网通信
	MCU 的 USART2 信号与 RS485 的信号通过跳线连接，SP3485 芯片
	实现 USART2 与 RS485 信号的转换
	
	USART2 使用 PA2, PA3 的复用功能
	RS485_RE 则使用 PG8 直接控制
	
	RS485 接线注意事项：
	A 接 A
	B 接 B
*/

/**
 * 功能：  初始化 RS485
 * 参数：  baudrate 波特率
 * 返回值：无
 **/
void RS485_init(uint32_t baudrate)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	// 使能 GPIOA 和 GPIOG 的时钟
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA 
		| RCC_AHB1Periph_GPIOG, ENABLE);
	// 使能 USART2 的时钟
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
	
	// 使能 PA2, PA3 的复用功能
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource2, GPIO_AF_USART2);
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource3, GPIO_AF_USART2);
	
	// 配置 PA2, PA3
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF;  // 复用功能
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;  // 推挽
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_2 | GPIO_Pin_3;
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(GPIOA, &GPIO_InitStruct);
	
	// 配置 PG8 
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;  // 通用输出
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_8;
	GPIO_Init(GPIOG, &GPIO_InitStruct);
	
	// 配置 USART2 
	USART_InitStructure.USART_BaudRate = baudrate;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_Init(USART2, &USART_InitStructure);
	
	// 配置 USART2 的 NVIC 中断
	NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
	NVIC_Init(&NVIC_InitStructure);
	
	// 使能 USART2
	USART_Cmd(USART2, ENABLE);
	
	// 配置使能接收非空中断，即接收非空时产生中断
	USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
	// 清空接收非空中断标志
	USART_ClearITPendingBit(USART2, USART_IT_RXNE);
	
	// 默认为接收
	RS485_RE_ENABLE();
}

// 在中断中接收字符
volatile static int rs485_recv_ch = EOF;

/**
 * 功能：  接收一字节数据
 * 参数：  无
 * 返回值：收到的一字节数据
 **/
int RS485_getchar(void)
{
	int ch;
	
	// 使能接收
	RS485_RE_ENABLE();
	
	// 等待数据
	while (EOF == rs485_recv_ch);
	ch = rs485_recv_ch;
	rs485_recv_ch = EOF;
	
	return ch;
}

/**
 * 功能：  发送一字节数据
 * 参数：  data 要发送的一字节数据
 * 返回值：成功返回 0，失败返回 -1
 **/
int RS485_putchar(int data)
{
	// 使能发送
	RS485_RE_DISABLE();
	// 等待可发送
	while (RESET == USART_GetFlagStatus(USART2, USART_FLAG_TXE));
	// 发送数据
	USART_SendData(USART2, data);
	// 等待发送完成 
	while (RESET == USART_GetFlagStatus(USART2, USART_FLAG_TC));
	// 使能接收
	RS485_RE_ENABLE();
	
	return 0;
}

/**
 * 功能：  获取字符串
 * 参数：  str 字符串存储缓冲区
 * 返回值：收到的字符串缓冲区指针
 **/
char *RS485_gets(char *str)
{
	char *s = str;
	
	while ((*str++ = RS485_getchar()) != '\n');
	*(--str) = '\0';
	
	return s;
}

/**
 * 功能：  发送字符串
 * 参数：  str 字符串存储缓冲区
 * 返回值：成功返回 0，失败返回 -1
 **/
int RS485_puts(char *str)
{
	while (*str)
	{
		RS485_putchar(*str++);
	}
	
	return 0;
}

// USART2 中断处理函数
void USART2_IRQHandler(void)
{
	if (SET == USART_GetITStatus(USART2, USART_IT_RXNE))
	{
		rs485_recv_ch = USART_ReceiveData(USART2);
		// 清空接收非空中断标志
		USART_ClearITPendingBit(USART2, USART_IT_RXNE);
	}
}
