
#ifndef _RS485_H_
#define _RS485_H_

#include "stm32f4xx.h"

#define RS485_RE_ENABLE()  do { GPIO_ResetBits(GPIOG, GPIO_Pin_8); } while (0)
#define RS485_RE_DISABLE() do { GPIO_SetBits(GPIOG, GPIO_Pin_8); } while (0)

/**
 * 功能：  初始化 RS485
 * 参数：  baudrate 波特率
 * 返回值：无
 **/
void RS485_init(uint32_t baudrate);

/**
 * 功能：  接收一字节数据
 * 参数：  无
 * 返回值：收到的一字节数据
 **/
int RS485_getchar(void);

/**
 * 功能：  发送一字节数据
 * 参数：  data 要发送的一字节数据
 * 返回值：成功返回 0，失败返回 -1
 **/
int RS485_putchar(int data);

/**
 * 功能：  获取字符串
 * 参数：  str 字符串存储缓冲区
 * 返回值：收到的字符串缓冲区指针
 **/
char *RS485_gets(char *str);

/**
 * 功能：  发送字符串
 * 参数：  str 字符串存储缓冲区
 * 返回值：成功返回 0，失败返回 -1
 **/
int RS485_puts(char *str);

#endif
