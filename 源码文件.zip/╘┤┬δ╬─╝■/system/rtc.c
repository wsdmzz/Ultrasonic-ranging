#include "rtc.h"
#include "stm32f4xx.h"
#include "stdio.h"
#include "stm32f4xx_rtc.h"

/**
 * 功能：  初始化 RTC
 * 参数：  无
 * 返回值：成功返回 0，失败返回 -1
 **/
int RTC_init(void)
{
	RTC_InitTypeDef RTC_InitStructure;
	uint32_t lsetimeout = 0;   // 超时计数器
	
	// PWR 电源控制寄存器 PWR_CR 的 DBP[8] 位置 1 使能备份域写访问
	// PWR 外设时钟使能
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR, ENABLE);
	// 通过电源控制寄存器 PWR_CR 使能备份域写访问
	PWR_BackupAccessCmd(ENABLE);
	
#define LSE_STARTUP_TIMEOUT 0x7FFF	
#define RTC_INITIALIZED 0x12345678
	
	// 获取 RTC 备份域寄存器 0 的值，判断是否已初始化，
	// 如果已初始化，则返回
	if (RTC_INITIALIZED == RTC_ReadBackupRegister(RTC_BKP_DR0))
	{
		return 0;
	}
	// 使能 LSE 时钟
	RCC_LSEConfig(RCC_LSE_ON);
	// 等待其就绪
	do 
	{
		lsetimeout++;
	} while ((RESET == RCC_GetFlagStatus(RCC_FLAG_LSERDY)) 
		&& lsetimeout <= LSE_STARTUP_TIMEOUT);
	if (lsetimeout > LSE_STARTUP_TIMEOUT)
	{
		return -1;   // 等待 LSE 就绪超时失败
	}
	
	// 选择时钟源为 LSE(32.768KHz)
	RCC_RTCCLKConfig(RCC_RTCCLKSource_LSE);
	// 使能 LSE 开始为 RTC 提供时钟
	RCC_RTCCLKCmd(ENABLE);
	
	// 异步预分频值为 128，取 7 位最大值
	RTC_InitStructure.RTC_AsynchPrediv = 0x7F;   
	// 同步预分频值为 256
	RTC_InitStructure.RTC_SynchPrediv = 0xFF;
	// 24 小时格式
	RTC_InitStructure.RTC_HourFormat = RTC_HourFormat_24;
	RTC_Init(&RTC_InitStructure);
	
	// 要解锁所有 RTC 寄存器（RTC_ISR[13:8]、RTC_TAFCR 和 RTC_BKPxR 除外）的写保护，
	// 需要执行以下步骤：
	// 1. 将“0xCA”写入 RTC_WPR 寄存器。
	// 2. 将“0x53”写入 RTC_WPR 寄存器。
	// 写入一个错误的关键字会再次激活写保护。
	// 解锁写保护
	RTC->WPR = 0xCA;
  RTC->WPR = 0x53;
	// 写入 RTC_INITIALIZED RTC 备份域寄存器 0
	RTC_WriteBackupRegister(RTC_BKP_DR0, RTC_INITIALIZED);
	// 再次激活写保护
	RTC->WPR = 0xFF;
	
	return 0;
}

// ErrorStatus RTC_SetTime(uint32_t RTC_Format, RTC_TimeTypeDef* RTC_TimeStruct);
// void RTC_GetTime(uint32_t RTC_Format, RTC_TimeTypeDef* RTC_TimeStruct);
// ErrorStatus RTC_SetDate(uint32_t RTC_Format, RTC_DateTypeDef* RTC_DateStruct);
// void RTC_GetDate(uint32_t RTC_Format, RTC_DateTypeDef* RTC_DateStruct);

/**
 * 功能：  设置时间
 * 参数：  RTC_Format 取值：RTC_Format_BIN, RTC_Format_BCD
 *         RTC_H12    取值：RTC_H12_AM, RTC_H12_PM
 *         hours      小时
 *         minutes    分钟 
 *         seconds    秒
 * 返回值：无
 **/
void RTC_set_time(uint32_t RTC_Format, uint8_t RTC_H12,
	uint32_t hours, uint32_t minutes, uint32_t seconds)
{
	RTC_TimeTypeDef RTC_TimeStructure;

	RTC_TimeStructure.RTC_H12 = RTC_H12;
	RTC_TimeStructure.RTC_Hours = hours;
	RTC_TimeStructure.RTC_Minutes = minutes;
	RTC_TimeStructure.RTC_Seconds = seconds;
	RTC_SetTime(RTC_Format, &RTC_TimeStructure);
}

/**
 * 功能：  设置日期
 * 参数：  RTC_Format 取值：RTC_Format_BIN, RTC_Format_BCD
 *         year       年
 *         month      月 参考 RTC_Month_Date_Definitions
 *         date       日
 *         week_day   星期 参考 RTC_WeekDay_Definitions
 * 返回值：无
 **/
void RTC_set_date(uint32_t RTC_Format, uint32_t year, 
	uint32_t month, uint32_t date, uint32_t week_day)
{
	RTC_DateTypeDef RTC_DateStructure;

	RTC_DateStructure.RTC_Date = date;
	if (RTC_Format_BIN == RTC_Format)
	{
		RTC_DateStructure.RTC_Year = year - 2000;
	}
	else
	{
		RTC_DateStructure.RTC_Year = year - (2 << 12);
	}
	RTC_DateStructure.RTC_Month = month;
	RTC_DateStructure.RTC_WeekDay = week_day;
	RTC_SetDate(RTC_Format, &RTC_DateStructure);
}

/**
 * 功能：  二进制数转换为四位 BCD 码
 * 参数：  Value 要转换的二进制数
 * 返回值：四位 BCD 码
 **/
uint16_t RTC_BinToBcd4(uint16_t Value)
{
  return ((Value / 1000) << 12) + ((Value / 100 % 10) << 8) +
			((Value % 100 / 10) << 4) + (Value % 10);
}

/**
 * 功能：  打印当前日期时间
 * 参数：  无
 * 返回值：无
 **/
void RTC_print_datetime(void)
{
	RTC_TimeTypeDef time;
	RTC_DateTypeDef date;
	char *weekday = "";
	
	// 先读时间
	RTC_GetTime(RTC_Format_BIN, &time);
	// 再读日期
	RTC_GetDate(RTC_Format_BIN, &date);

	printf("%4d-%02d-%02d %02d:%02d:%02d ", 
		date.RTC_Year + 2000, date.RTC_Month, date.RTC_Date,
		time.RTC_Hours, time.RTC_Minutes, time.RTC_Seconds); 
	switch (date.RTC_WeekDay)
	{
		case RTC_Weekday_Monday: weekday = "Monday"; break;
		case RTC_Weekday_Tuesday: weekday = "Tuesday"; break;
		case RTC_Weekday_Wednesday: weekday = "Wednesday"; break;
		case RTC_Weekday_Thursday: weekday = "Thursday"; break;
		case RTC_Weekday_Friday: weekday = "Friday"; break;
		case RTC_Weekday_Saturday: weekday = "Saturday"; break;
		case RTC_Weekday_Sunday: weekday = "Sunday"; break;
	}
	printf("%s", weekday);
}

/**
 * 功能：  按星期设置闹钟 A
 * 参数：  weekday 星期几，参考 RTC_WeekDay_Definitions
 *         hours   时
 *         minutes 分
 *         seconds 秒
 * 返回值：无
 **/
void RTC_set_alarma(uint32_t weekday, uint32_t hours, uint32_t minutes, uint32_t seconds)
{
	/*
	所有 RTC 中断均与 EXTI 控制器相连。
	要使能 RTC 闹钟中断，需按照以下顺序操作：
	1. 将 EXTI 线 17 配置为中断模式并将其使能，然后选择上升沿有效。
	2. 配置 NVIC 中的 RTC_Alarm IRQ 通道并将其使能。
	3. 配置 RTC 以生成 RTC 闹钟（闹钟 A 或闹钟 B）。
	
	要对可编程的闹钟（闹钟 A 或闹钟 B）进行编程或更新，必须执行类似的步骤：
	1. 将 RTC_CR 寄存器中的 ALRAE 或 ALRBE 位清零以禁止闹钟 A 或闹钟 B。
	2. 轮询 RTC_ISR 寄存器中的 ALRAWF 或 ALRBWF 位，直到其中一个置 1，以确保闹钟
	   寄存器可以访问。大约需要 2 个 RTCCLK 时钟周期（由于时钟同步）。
	3. 编程闹钟 A 或闹钟 B 寄存器（RTC_ALRMASSR/RTC_ALRMAR 或 RTC_ALRMBSSR/
	   RTC_ALRMBR）。
	4. 将 RTC_CR 寄存器中的 ALRAE 或 ALRBE 位置 1 以再次使能闹钟 A 或闹钟 B。
	
	EXTI 线 17 连接到 RTC 闹钟事件
	*/
	EXTI_InitTypeDef EXTI_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	RTC_AlarmTypeDef RTC_AlarmStructure;
	
	// 初始化 EXTI 线 17 
	// 清除 EXTI 线 17 的中断标志
	EXTI_ClearITPendingBit(EXTI_Line17);
	EXTI_InitStructure.EXTI_Line = EXTI_Line17;
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;  // 上升沿触发
	EXTI_Init(&EXTI_InitStructure);
	
	// 初始化 NVIC 的 RTC_Alarm IRQ 通道
	NVIC_InitStructure.NVIC_IRQChannel = RTC_Alarm_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
	NVIC_Init(&NVIC_InitStructure);
	
	// 禁止闹钟 A
	RTC_AlarmCmd(RTC_Alarm_A, DISABLE);
	// void RTC_SetAlarm(uint32_t RTC_Format, uint32_t RTC_Alarm, RTC_AlarmTypeDef* RTC_AlarmStruct);
	// 等待 RTC 寄存器可访问
	while((RTC->ISR & RTC_ISR_ALRAWF) == 0x00);
	// 初始化闹钟 A
	RTC_AlarmStructure.RTC_AlarmDateWeekDay = weekday;
	RTC_AlarmStructure.RTC_AlarmDateWeekDaySel = RTC_AlarmDateWeekDaySel_WeekDay;
	RTC_AlarmStructure.RTC_AlarmMask = RTC_AlarmMask_None;
	RTC_AlarmStructure.RTC_AlarmTime.RTC_H12 = RTC_H12_AM;
	RTC_AlarmStructure.RTC_AlarmTime.RTC_Hours = hours;
	RTC_AlarmStructure.RTC_AlarmTime.RTC_Minutes = minutes;
	RTC_AlarmStructure.RTC_AlarmTime.RTC_Seconds = seconds;
	RTC_SetAlarm(RTC_Format_BIN, RTC_Alarm_A, &RTC_AlarmStructure);

	// 使能闹钟 A
	RTC_AlarmCmd(RTC_Alarm_A, ENABLE);
	// 清除闹钟 A 中断
	RTC_ClearITPendingBit(RTC_IT_ALRA);
	// 使能闹钟 A 中断
	RTC_ITConfig(RTC_IT_ALRA, ENABLE);
	
}
/*
void RTC_ITConfig(uint32_t RTC_IT, FunctionalState NewState);
FlagStatus RTC_GetFlagStatus(uint32_t RTC_FLAG);
void RTC_ClearFlag(uint32_t RTC_FLAG);
ITStatus RTC_GetITStatus(uint32_t RTC_IT);
void RTC_ClearITPendingBit(uint32_t RTC_IT);
*/

/**
 * 功能：  设置 RTC 周期性唤醒中断
 * 参数：  seconds 唤醒间隔秒数
 * 返回值：无
 **/
void RTC_set_wakeup(uint32_t seconds)
{
	/*
	要使能 RTC 唤醒中断，需按照以下顺序操作：
	1. 将 EXTI 线 22 配置为中断模式并将其使能，然后选择上升沿有效。
	2. 配置 NVIC 中的 RTC_WKUP IRQ 通道并将其使能。
	3. 配置 RTC 以生成 RTC 唤醒定时器事件。
	
	编程唤醒定时器
	要配置或更改唤醒定时器的自动重载值（RTC_WUTR 中的 WUT[15:0]），需要按照以下顺
  序操作：
  1. 清零 RTC_CR 中的 WUTE 以禁止唤醒定时器。
  2. 轮询 RTC_ISR 中的 WUTWF，直到该位置 1，以确保可以访问唤醒自动重载定时器和
     WUCKSEL[2:0] 位。大约需要 2 个 RTCCLK 时钟周期（由于时钟同步）。
  3. 编程唤醒自动重载值 WUT[15:0]，并选择唤醒时钟（RTC_CR 中的 WUCKSEL[2:0] 位）。
     将 RTC_CR 寄存器中的 WUTE 位置 1 以再次使能定时器。唤醒定时器重新开始递减
     计数。
	
	EXTI 线 22 连接到 RTC 唤醒事件
	*/
	EXTI_InitTypeDef EXTI_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	// 初始化 EXTI 线 22
	// 清除 EXTI 线 22 的中断标志
	EXTI_ClearITPendingBit(EXTI_Line2);
	EXTI_InitStructure.EXTI_Line = EXTI_Line22;
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;  // 上升沿触发
	EXTI_Init(&EXTI_InitStructure);
	
	// 初始化 NVIC 的 RTC_WKUP IRQ 通道
	NVIC_InitStructure.NVIC_IRQChannel = RTC_WKUP_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
	NVIC_Init(&NVIC_InitStructure);
	
	// 禁用唤醒中断
	RTC_WakeUpCmd(DISABLE);
	// 等待可访问唤醒自动重载定时器和 WUCKSEL[2:0] 位
	while((RTC->ISR & RTC_ISR_WUTWF) == 0x00);
	// 选择 RTC 唤醒递减定时器时钟源为 RTCCLK / 16 = 32768 / 16 = 2048
	RTC_WakeUpClockConfig(RTC_WakeUpClock_RTCCLK_Div16);
	// 设置计数值，一秒有多少个计数值，参考以上公式
	RTC_SetWakeUpCounter(seconds * 2048 - 1);
	// 清除 唤醒 标志
	RTC_ClearITPendingBit(RTC_IT_WUT);  
	// 启用唤醒
	RTC_WakeUpCmd(ENABLE);    
	// 使能 唤醒 中断
	RTC_ITConfig(RTC_IT_WUT, ENABLE); 
}

volatile int rtc_alarma_flag = 0;   // 0 表示闹钟没到点，1 表示闹钟到点

// RTC 闹钟中断处理程序
void RTC_Alarm_IRQHandler(void)
{
	// 是闹钟 A 中断
	if (RTC_GetITStatus(RTC_IT_ALRA))
	{
		rtc_alarma_flag = 1;
		// 清除闹钟 A 中断标志
		RTC_ClearITPendingBit(RTC_IT_ALRA);
	}
	// 清除中断线 17 中断标志
	EXTI_ClearITPendingBit(EXTI_Line17);
}

// RTC 周期性唤醒中断处理程序
void RTC_WKUP_IRQHandler(void)
{
	// 这是为了测试的需要而在中断处理程序中打印，
	// 生产中不能这样处理
	printf("\n唤醒中断 ... ");
	RTC_print_datetime();
	printf("\n");
	// 清除 RTC 周期性唤醒中断标志
	RTC_ClearITPendingBit(RTC_IT_WUT);
	// 清除中断线 22 中断标志
	EXTI_ClearITPendingBit(EXTI_Line22);
}

