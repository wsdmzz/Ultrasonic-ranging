
#ifndef _RTC_H_
#define _RTC_H_

#include "stm32f4xx.h"

extern volatile int rtc_alarma_flag;   // 0 表示闹钟没到点，1 表示闹钟到点

/**
 * 功能：  初始化 RTC
 * 参数：  无
 * 返回值：成功返回 0，失败返回 -1
 **/
int RTC_init(void);

/**
 * 功能：  设置时间
 * 参数：  RTC_Format 取值：RTC_Format_BIN, RTC_Format_BCD
 *         RTC_H12    取值：RTC_H12_AM, RTC_H12_PM
 *         hours      小时
 *         minutes    分钟 
 *         seconds    秒
 * 返回值：无
 **/
void RTC_set_time(uint32_t RTC_Format, uint8_t RTC_H12,
	uint32_t hours, uint32_t minutes, uint32_t seconds);

/**
 * 功能：  设置日期
 * 参数：  RTC_Format 取值：RTC_Format_BIN, RTC_Format_BCD
 *         year       年
 *         month      月 参考 RTC_Month_Date_Definitions
 *         date       日
 *         week_day   星期 参考 RTC_WeekDay_Definitions
 * 返回值：无
 **/
void RTC_set_date(uint32_t RTC_Format, uint32_t year, 
	uint32_t month, uint32_t date, uint32_t week_day);

/**
 * 功能：  打印当前日期时间
 * 参数：  无
 * 返回值：无
 **/
void RTC_print_datetime(void);

/**
 * 功能：  二进制数转换为四位 BCD 码
 * 参数：  Value 要转换的二进制数
 * 返回值：四位 BCD 码
 **/
uint16_t RTC_BinToBcd4(uint16_t Value);

/**
 * 功能：  按星期设置闹钟 A
 * 参数：  weekday 星期几，参考 RTC_WeekDay_Definitions
 *         hours   时
 *         minutes 分
 *         seconds 秒
 * 返回值：无
 **/
void RTC_set_alarma(uint32_t weekday, uint32_t hours, uint32_t minutes, uint32_t seconds);

/**
 * 功能：  设置 RTC 周期性唤醒中断
 * 参数：  seconds 唤醒间隔秒数
 * 返回值：无
 **/
void RTC_set_wakeup(uint32_t seconds);

#endif
