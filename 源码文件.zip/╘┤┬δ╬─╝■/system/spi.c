#include "spi.h"

/*
	查原理图得知：
	
	SPI1 外接 W25Q128 FLASH 和 NRF24L01 无线通信芯片
	
	SPI1 外接的芯片，如 W25Q128 和 NRF24L01 公用以下三个信号：
	SPI1_MISO  --  PB4
	SPI1_MOSI  --  PB5
	SPI1_SCK   --  PB3
	
	F_CS       --  PB14 (W25Q128 的片选)  -- 通过 GPIOB 控制 

	NRF_CS     --  PG7  (NRF24L01 的片选) -- 通过 GPIOG 控制

	其中 F_CS 和 NRF_CS 并不受 SPI1 控制，因此只能使用 GPIO 控制。

	SPI 的四种时钟极性和相位模式：
	模式  CPOL  CPHA
	  0     0     0
		1     0     1
		2     1     0
		3     1     1
	W25Q128 的《6.1.1 Standard SPI Instructions》节说明了所支持的模式：
	"SPI bus operation Mode 0 (0,0) and 3 (1,1) are supported."
*/

/**
 * 功能：  初始化 SPI1 和 W25Q128
 * 参数：  无
 * 返回值：无
 **/
void SPI1_w25q128_init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	SPI_InitTypeDef SPI_InitStructure;
	
	// 使能 GPIOB, GPIOG, SPI1 时钟
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOG, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_SPI1, ENABLE);
	
	// PB3, PB4, PB5 复用功能配置
	GPIO_PinAFConfig(GPIOB, GPIO_PinSource3, GPIO_AF_SPI1);
	GPIO_PinAFConfig(GPIOB, GPIO_PinSource4, GPIO_AF_SPI1);
	GPIO_PinAFConfig(GPIOB, GPIO_PinSource5, GPIO_AF_SPI1);
	
	// 初始化 PB3, PB4, PB5 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	// 初始化 PB14
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	// 初始化 PG7
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
	GPIO_Init(GPIOG, &GPIO_InitStructure);
	
	// 禁用 W25Q128 和 NRF24L01
	SPI1_W25Q128_DISABLE();
	SPI1_NRF24L01_DISABLE();
	
	// SPI1 初始化
	// f PCLK / 2，即 APB2 总线时钟（84MHz） 2 分频 = 42MHz
	SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_2;
	// 应该查询所通信的芯片支持哪些模式，
	// W25Q128 支持模式 0 和 模式 3，此处选择模式 3
	// 如果是模式 0 则 SPI_CPOL=  SPI_CPOL_Low
	// SPI_CPHA = SPI_CPHA_1Edge
	SPI_InitStructure.SPI_CPOL = SPI_CPOL_High;
	SPI_InitStructure.SPI_CPHA = SPI_CPHA_2Edge;
	// 8 位数据配置多项式寄存器值为 7
	// 16 位数据配置多项式寄存器值为 15
	SPI_InitStructure.SPI_CRCPolynomial = 0x7;   // 8 位数据配置 7
	SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
	// 双线全双工
	SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
	// 先传最高有效位 MSB
	SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
	// 主模式
	SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
	// 可以选择"软件按理 NSS"还是"硬件管理 NSS" 
	SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
	SPI_Init(SPI1, &SPI_InitStructure);
	
	// 使能 SPI1
	SPI_Cmd(SPI1, ENABLE);
}

// 数据收发函数
// void SPI_I2S_SendData(SPI_TypeDef* SPIx, uint16_t Data);
// uint16_t SPI_I2S_ReceiveData(SPI_TypeDef* SPIx);

// 标志管理函数 
// FlagStatus SPI_I2S_GetFlagStatus(SPI_TypeDef* SPIx, uint16_t SPI_I2S_FLAG);
// void SPI_I2S_ClearFlag(SPI_TypeDef* SPIx, uint16_t SPI_I2S_FLAG);

/**
 * 功能：  通用读写函数
 * 参数：  data 发送的数据
 * 返回值：收到的数据
 **/
uint8_t SPI1_read_write_byte(uint8_t data)
{
	// 等待可发送数据（发送空标志为真）
	while (RESET == SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_TXE));
	// 发送数据 
	SPI_I2S_SendData(SPI1, data);
	// 等待可接收数据（接收非空标志为真）
	while (RESET == SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_RXNE));
	// 接收数据
	return SPI_I2S_ReceiveData(SPI1);
}

/*
	W25Q128 存储空间：
	共 16MB 字节：
	1片 = 256 块
	1块 = 16 扇区
	1扇区 = 16页
	1页 = 256字节

	可扇区擦除、块擦除、片擦除。
	共 4096 个可擦除扇区，256 个可擦除块。
*/

/**
 * 功能：  获取制造商和设备 ID
 * 参数：  无
 * 返回值：制造商和设备 ID，其中 制造商 ID 占高 8 位
 **/
uint16_t SPI1_w25q128_get_id(void)
{
	uint16_t id = 0;
	
	// 使能 W25Q128
	SPI1_W25Q128_ENABLE();
	
	SPI1_read_write_byte(W25Q128_READ_ID);
	SPI1_read_write_byte(W25Q128_DUMMY);
	SPI1_read_write_byte(W25Q128_DUMMY);
	SPI1_read_write_byte(W25Q128_NULL);
	// 先返回制造商 ID
	id = SPI1_read_write_byte(W25Q128_NULL) << 8;
	// 后返回设备 ID
	id |= SPI1_read_write_byte(W25Q128_NULL);
	
	// 禁用 W25Q128
	SPI1_W25Q128_DISABLE();
	
	return id;
}

/**
 * 功能：  读取状态寄存器 1
 * 参数：  无
 * 返回值：状态寄存器值
 *         S7   S6  S5 S4  S3  S2  S1  S0
 *         SRP0 SEC TB BP2 BP1 BP0 WEL BUSY
 *         SRP0 - 状态寄存器保护
 *         SEC  - 扇区保护位
 *         TB   - 顶/底扇区保护位
 *         BP2 BP1 BP0 - 块保护位
 *         WEL  - 写使能锁存
 *         BUSY - 忙，擦除/写进行中
 **/
uint8_t SPI1_w25q128_read_status1(void)
{
	uint8_t status = 0;
	
	// 使能 W25Q128
	SPI1_W25Q128_ENABLE();
	
	SPI1_read_write_byte(W25Q128_READ_STATUS1);
	status = SPI1_read_write_byte(W25Q128_NULL);
	
	// 禁用 W25Q128
	SPI1_W25Q128_DISABLE();
	
	return status;
}

/**
 * 功能：  写使能/禁用
 * 参数：  使能/禁用命令字：
 *             W25Q128_WRITE_ENABLE
 *             W25Q128_WRITE_DISABLE
 * 返回值：无
 *
 * 说明：  在以下操作之前必须写使能：
 *             页写、四位页写、扇区擦除、块擦除、
 *             片擦除、写状态寄存器、擦除/写安全寄存器
 **/
void SPI1_w25q128_write_cmd(uint8_t cmd)
{
	// 使能 W25Q128
	SPI1_W25Q128_ENABLE();
	
	// 发送使能/禁用命令字
	SPI1_read_write_byte(cmd);
	
	// 禁用 W25Q128
	SPI1_W25Q128_DISABLE();
}

/*
	注意事项：
	1. 写、擦除后必须读取状态，等待总线 "BUSY" 完毕
	2. 写、擦除前必须"写使能"，完毕后再"写禁用"
*/

// 作业：完成页写、扇区擦除、读数据等函数


