#ifndef _SPI_H_
#define _SPI_H_

#include "stm32f4xx.h"

#define SPI1_W25Q128_ENABLE() do { GPIO_ResetBits(GPIOB, GPIO_Pin_14); } while (0)
#define SPI1_W25Q128_DISABLE() do { GPIO_SetBits(GPIOB, GPIO_Pin_14); } while (0)

#define SPI1_NRF24L01_ENABLE() do { GPIO_ResetBits(GPIOG, GPIO_Pin_7); } while (0)
#define SPI1_NRF24L01_DISABLE() do { GPIO_SetBits(GPIOG, GPIO_Pin_7); } while (0)

// W25Q128 命令字
#define W25Q128_READ_ID       0x90
#define W25Q128_DUMMY         0xFF
#define W25Q128_NULL          0x00
#define W25Q128_READ_STATUS1  0x05
#define W25Q128_WRITE_ENABLE  0x06
#define W25Q128_WRITE_DISABLE 0x04


/**
 * 功能：  初始化 SPI1 和 W25Q128
 * 参数：  无
 * 返回值：无
 **/
void SPI1_w25q128_init(void);

/**
 * 功能：  通用读写函数
 * 参数：  data 发送的数据
 * 返回值：收到的数据
 **/
uint8_t SPI1_read_write_byte(uint8_t data);

/**
 * 功能：  获取制造商和设备 ID
 * 参数：  无
 * 返回值：制造商和设备 ID，其中 制造商 ID 占高 8 位
 **/
uint16_t SPI1_w25q128_get_id(void);

/**
 * 功能：  写使能/禁用
 * 参数：  使能/禁用命令字：
 *             W25Q128_WRITE_ENABLE
 *             W25Q128_WRITE_DISABLE
 * 返回值：无
 *
 * 说明：  在以下操作之前必须写使能：
 *             页写、四位页写、扇区擦除、块擦除、
 *             片擦除、写状态寄存器、擦除/写安全寄存器
 **/
void SPI1_w25q128_write_cmd(uint8_t cmd);

#endif 
