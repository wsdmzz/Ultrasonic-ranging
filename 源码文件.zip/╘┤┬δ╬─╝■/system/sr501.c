#include "sr501.h"




void SR501_init(void)
{
  GPIO_InitTypeDef  GPIO_InitStructure;
  
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);

	//GPIO_InitStructure.GPIO_Speed = GPIO_High_Speed;
//	GPIO_InitStruct.GPIO_OType = GPIO_OType_DOWN;
	GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_UP;
	
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
  GPIO_Init(GPIOB, &GPIO_InitStructure);	
	
	//GPIO_SetBits(GPIOA, GPIO_Pin_10);
}

void sr501_test(void)
{
	// �ȴ�����ߵ�ƽ
	while(!(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_11)))
	{
		if(0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_11))
		{
			beeps(2, 20);
			
	//	Delay(5);
		
			break;
		}
		else
		{
			//break;
		}
	}
	Delay(100);
}


