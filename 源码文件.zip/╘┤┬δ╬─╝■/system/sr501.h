#ifndef _SR501_H_
#define _SR501_H_

#include "beep.h"
#include "delay.h"
#include "stm32f4xx.h"

void SR501_init(void);

void sr501_test(void);

#endif
