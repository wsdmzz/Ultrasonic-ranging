

#include "systick.h"

static uint32_t fac_us;    // us 因子/系数
//static uint32_t fac_ms;    // us 因子/系数

/**
 * 功能：  初始化 SysTick
 * 参数：  无
 * 返回值：无
 **/ 
void SysTick_init(void)
{
	RCC_ClocksTypeDef RCC_Clocks;
	// 获取时钟
	RCC_GetClocksFreq(&RCC_Clocks);
	// 配置 SysTick 的时钟源为 AHB/8
	// 即 168MHz / 8 = 21MHz
	SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK_Div8);
	// 计算 us 和 ms 因子
	fac_us = RCC_Clocks.HCLK_Frequency / 8 / 1000000;   // 21
	//fac_ms = fac_us * 1000;   // 21000
}

#if 0
/**
 * 功能：  延时 nus 微秒
 * 参数：  nus 要延时的 us 数，不能超 0x00FFFFFFUL
 * 返回值：无
 **/
static void _delay_us(uint32_t nus)
{
	// 设置重加载值
	SysTick->LOAD = (nus * fac_us - 1UL) & 0x00FFFFFFUL;
	// 清空当前计数值
	SysTick->VAL = 0UL;
	// 使能计数器
	SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk;
	// 等待计数到 0，当 SysTick->CTRL 的 [16] 位为 1 则说明
	// SysTick->VAL 计数到 0 了，[16] 位为 0 说明没有计数到 0
	while (0 == (SysTick->CTRL & SysTick_CTRL_COUNTFLAG_Msk));
	// 禁用计数器
	SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;
	// 清空当前计数值
	SysTick->VAL = 0UL;
}

/**
 * 功能：  延时 nus 微秒
 * 参数：  nus 要延时的 us 数，可取 0x0UL - 0xFFFFFFFFUL 范围的值
 * 返回值：无
 **/
void delay_us(uint32_t nus)
{
	uint32_t remain = nus;
	// 计算单次最大可延时的 us 数
	nus = 0x00FFFFFFUL / fac_us;
	// 以单次最大可延时 us 数进行延时
	while (remain > nus)
	{
		_delay_us(nus);
		remain -= nus;
	}
	// 延时剩余 us 数
	_delay_us(remain);
}

/**
 * 功能：  延时 nms 毫秒
 * 参数：  nms 要延时的 ms 数，可取 0x0UL - 0xFFFFFFFFUL 范围的值
 * 返回值：无
 **/
void delay_ms(uint32_t nms)
{
	uint32_t i;
	for (i = 0; i < nms; i++)
	{
		delay_us(1000);
	}
}

#endif
