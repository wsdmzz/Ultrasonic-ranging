#if 0
#ifndef _SYSTICK_H_
#define _SYSTICK_H_

#include "stm32f4xx.h"

/**
 * 功能：  初始化 SysTick
 * 参数：  无
 * 返回值：无
 **/ 
//void SysTick_init(void);

/**
 * 功能：  延时 nus 微秒
 * 参数：  nus 要延时的 us 数，可取 0x0UL - 0xFFFFFFFFUL 范围的值
 * 返回值：无
 **/
void delay_us(uint32_t nus);

/**
 * 功能：  延时 nms 毫秒
 * 参数：  nms 要延时的 ms 数，可取 0x0UL - 0xFFFFFFFFUL 范围的值
 * 返回值：无
 **/
void delay_ms(uint32_t nms);

#endif
#endif

#ifndef _SYSTICK_H_
#define _SYSTICK_H_

#include "stm32f4xx.h"

/**
 * 功能：  初始化 SysTick
 * 参数：  无
 * 返回值：无
 **/ 
void SysTick_init(void);

// 延时
void Delay(__IO uint32_t nTime);
void TimingDelay_Decrement(void);
void delay_init(uint8_t SYSCLK);
void delay_ms(uint16_t nms);
void delay_us(uint32_t nus);

#endif
