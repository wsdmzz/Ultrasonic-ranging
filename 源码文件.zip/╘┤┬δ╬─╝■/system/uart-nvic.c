#include "uart-nvic.h"
#include "stdio.h"
#include "stdarg.h"
#include "led.h"

/*
	注意：
	SCB 和 NVIC 在《DM00031020_zh(中文参考手册)》中并没有相关说明，
	可参考《en.DM00046982(内核编程手册)》的《4.3  Nested vectored
	interrupt controller (NVIC)》。
	NVIC 有 0 - 15 个可编程优先级，数值越大优先级越低，因此 0 级
	优先级最高。
	支持电平和脉冲（边沿）检测中断。
	优先级可以分组为组 0 - 组4，每组又分为抢占优先级和响应优先级。
	组0：抢占优先级 0 位，响应优先级 4 位
	组1：抢占优先级 1 位，响应优先级 3 位
	组2：抢占优先级 2 位，响应优先级 2 位
	组3：抢占优先级 3 位，响应优先级 1 位
	组4：抢占优先级 4 位，响应优先级 0 位
	分组是通过 SCB->AIRCR 的 PRIGROUP域[10:8] 配置的。
	组 0：0b111
	组 1：0b110
	组 2：0b101
	组 3：0b100
	组 4：0b011
*/

/**
 * 功能：  以波特率 baudrate 初始化 USART1(NVIC中断方式)
 * 参数：  baudrate 波特率
 * 返回值：无
 */
void USART1_nvic_init(int baudrate)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	// 1) 串口时钟使能，GPIO 时钟使能。
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
	
	// 2) 设置引脚复用器映射：调用 GPIO_PinAFConfig 函数。
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource9, GPIO_AF_USART1);
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource10, GPIO_AF_USART1);
	
	// 3) GPIO 初始化设置：要设置模式为复用功能。
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;  // 复用功能
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;  // 推挽
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9 | GPIO_Pin_10;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;    // 上拉
	GPIO_InitStructure.GPIO_Speed = GPIO_High_Speed;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	// 4) 串口参数初始化：设置波特率，字长，奇偶校验等参数。
	USART_InitStructure.USART_BaudRate = baudrate;  // 波特率
	USART_InitStructure.USART_HardwareFlowControl = 
	USART_HardwareFlowControl_None;  // 无流控
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	USART_InitStructure.USART_Parity = USART_Parity_No;     // 无校验
	USART_InitStructure.USART_StopBits = USART_StopBits_1;  // 1 位停止位
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_Init(USART1, &USART_InitStructure);
	
	// 5) 使能串口。
	USART_Cmd(USART1, ENABLE);
	
	// NVIC 初始化 USART1 中断
	NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2; // 抢占优先级
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;   // 响应优先
	NVIC_Init(&NVIC_InitStructure);
	
	// void USART_ITConfig(USART_TypeDef* USARTx, uint16_t USART_IT, FunctionalState NewState);
	// FlagStatus USART_GetFlagStatus(USART_TypeDef* USARTx, uint16_t USART_FLAG);
	// void USART_ClearFlag(USART_TypeDef* USARTx, uint16_t USART_FLAG);
	// ITStatus USART_GetITStatus(USART_TypeDef* USARTx, uint16_t USART_IT);
	// void USART_ClearITPendingBit(USART_TypeDef* USARTx, uint16_t USART_IT);
	// 配置使能接收非空中断，即接收非空时产生中断
	USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);
	// 清空接收非空中断标志
	USART_ClearITPendingBit(USART1, USART_IT_RXNE);
}

// 中断处理程序（中断服务程序 ISR）
/*
   注意中断处理程序的名称必须与中断向量表中一致。

   中断处理程序不是在正常的程序的上下文中执行。 
   即不是正常的通过函数调用执行，而是通过中断执行。

   中断处理程序注意事项：
   1. 没有参数      
      原因：不是通过代码显式调用，无法传递参数
   2. 没有返回值    
      原因：不是通过代码显式调用，无法返回值
   3. 不要做浮点运算  
      原因：浮点运算很耗时，而中断服务程序必须快速完成
   4. 不要使用标准输出函数 printf
      原因：printf 可能导致休眠，而中断报备程序中不能休眠
*/

// 以下对 USART1 的接收处理是简单的处理方式，如果主程序中
// 没有及时接收字符，则之前收到的字符会被覆盖
// recv_ch 是接收默认为未收到字符
volatile int recv_ch = EOF;   
void USART1_IRQHandler(void)
{
	// 是接收非空中断
	if (SET == USART_GetITStatus(USART1, USART_IT_RXNE))
	{
		// 接收字符
		recv_ch = USART_ReceiveData(USART1);
		// 清空接收非空中断标志
		USART_ClearITPendingBit(USART1, USART_IT_RXNE);
	}
}

/**
 * 功能：  获取 USART1 一个字节数据
 * 参数：  无
 * 返回值：从 USART1 获取的一个字节数据
 **/
int usart1_nvic_getchar(void)
{
	int ch;
	
	// 如果 recv_ch 为 EOF 则说明还没有收到字符，那么就等待
	while (EOF == recv_ch);
	// 获取一个字节
	ch = recv_ch;
	// 回显
	usart1_nvic_putchar(ch);
	if (ch == '\r')
	{
		usart1_nvic_putchar('\n');
	}
	recv_ch = EOF;
	
	return ch;
}

/**
 * 功能：  从 USART1 发送一字节数据 data
 * 参数：  data 要发送的一字节数据
 * 返回值：成功返回 0，失败返回 -1
 **/
int usart1_nvic_putchar(int data)
{
	if (data == '\n')
	{
		usart1_nvic_putchar('\r');
	}
	// 等待发送空标志
	// USART_GetFlagStatus() 函数对于 USART_FLAG_TXE 标志，
	// 返回 SET 表示可以发送数据，RESET 表示不能发送数据
	while (RESET == USART_GetFlagStatus(USART1, USART_FLAG_TXE));
	// 发送数据
	USART_SendData(USART1, data);
	
	return 0;
}

/**
 * 功能：  从 USART1 获取字符串存入 buf 中
 * 参数：  buf 字符指针，用于存储接收的数据
 * 返回值：成功返回 0，失败返回 -1
 **/ 
int usart1_nvic_gets(char *buf)
{
	while ('\r' != (*buf++ = usart1_nvic_getchar()));
	buf--;
	*buf = '\0';
	
	return 0;
}

/**
 * 功能：  从 USART1 发送字符串 buf
 * 参数：  buf 字符指针，用于存储发送的数据
 * 返回值：成功返回 0，失败返回 -1
 **/ 
int usart1_nvic_puts(char *buf)
{
	while (*buf)
	{
		usart1_nvic_putchar(*buf++);
	}
	
	return 0;
}

/**
 * 功能：  模仿标准格式化输出函数 printf 
 * 参数：  format 格式化字符串
 * 返回值：成功返回格式化成功的字符个数，失败返回 -1
 **/
int usart1_nvic_printf(const char *format, ...)
{
	va_list ap;
	char buf[64];
	int cnt;
	
	va_start(ap, format);
	// 将 format 格式字符串生成的字符串存入 buf 中
	cnt = vsnprintf(buf, sizeof buf, format, ap);
	va_end(ap);
	// 输出转换后的字符串
	if (cnt > 0)
	{
		usart1_nvic_puts(buf);
	}
	
	return cnt;
}

#if 0
// --------------------------------------------------------
// 将标准输入输出重定向到 USART1 

// keil 的安装目录，如：C:\Keil_v5\ARM\Startup 下有一个文件
// Retarget.c。
// 此文件中有重定向标准输入输出到开发板的输入输出的示例
// 以下是复制此文件并做修改。

#include <stdio.h>
#include <time.h>
#include <rt_misc.h>

// 不使用“半主机函数”
#pragma import(__use_no_semihosting_swi)


//extern int  sendchar(int ch);  /* in Serial.c */
//extern int  getkey(void);      /* in Serial.c */
extern long timeval;           /* in Time.c   */


struct __FILE { int handle; /* Add whatever you need here */ };
FILE __stdout;
FILE __stdin;

// 打印字符
int fputc(int ch, FILE *f) {
  //return (sendchar(ch));
	return usart1_nvic_putchar(ch);
}

// 获取字符
int fgetc(FILE *f) {
  //return (sendchar(getkey()));
	return usart1_nvic_getchar();
}

// 判断错误
int ferror(FILE *f) {
  /* Your implementation of ferror */
  return EOF;
}


void _ttywrch(int ch) {
  //sendchar (ch);
	usart1_nvic_putchar(ch);
}


void _sys_exit(int return_code) {
  while (1);    /* endless loop */
}

#endif
