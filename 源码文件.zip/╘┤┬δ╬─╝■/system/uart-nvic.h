
#ifndef _UART_NVIC_H_
#define _UART_NVIC_H_

#include "stm32f4xx.h"

/**
 * 功能：  以波特率 baudrate 初始化 USART1(NVIC中断方式)
 * 参数：  baudrate 波特率
 * 返回值：无
 */
void USART1_nvic_init(int baudrate);

/**
 * 功能：  获取 USART1 一个字节数据
 * 参数：  无
 * 返回值：从 USART1 获取的一个字节数据
 **/
int usart1_nvic_getchar(void);

/**
 * 功能：  从 USART1 发送一字节数据 data
 * 参数：  data 要发送的一字节数据
 * 返回值：成功返回 0，失败返回 -1
 **/
int usart1_nvic_putchar(int data);

/**
 * 功能：  从 USART1 获取字符串存入 buf 中
 * 参数：  buf 字符指针，用于存储接收的数据
 * 返回值：成功返回 0，失败返回 -1
 **/ 
int usart1_nvic_gets(char *buf);

/**
 * 功能：  从 USART1 发送字符串 buf
 * 参数：  buf 字符指针，用于存储发送的数据
 * 返回值：成功返回 0，失败返回 -1
 **/ 
int usart1_nvic_puts(char *buf);

/**
 * 功能：  模仿标准格式化输出函数 printf 
 * 参数：  format 格式化字符串
 * 返回值：成功返回格式化成功的字符个数，失败返回 -1
 **/
int usart1_nvic_printf(const char *format, ...);

#endif
