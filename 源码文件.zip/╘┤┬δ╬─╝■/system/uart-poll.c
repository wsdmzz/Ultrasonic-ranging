
#include "uart-poll.h"
#include "stdarg.h"
#include "stdio.h"

/*
	通过查看原理图得知，开发板是通过 CH340G 实现 USART1 与
	USB 的转换。
	USB D+/D-  --> CH340G --> RXD/TXD --> UART1 的 1,3 和 2,4
	--> USART1_TX/USART1_RX --> PA9/PA10
	但是这里并不需要直接操作 PA9/PA10，而是通过 USART1 外设的
	寄存器实现发送和接收
	因为使用了 PA9/PA10 两个引脚，因此需要同时配置 PA9/PA10 和
	USART1 两种外设。
*/

/**
 * 功能：  以波特率 baudrate 初始化 USART1(轮询方式)
 * 参数：  baudrate 波特率
 * 返回值：无
 */
void USART1_poll_init(int baudrate)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	
	// 1) 串口时钟使能，GPIO 时钟使能。
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
	
	// 2) 设置引脚复用器映射：调用 GPIO_PinAFConfig 函数。
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource9, GPIO_AF_USART1);
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource10, GPIO_AF_USART1);
	
	// 3) GPIO 初始化设置：要设置模式为复用功能。
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;  // 复用功能
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;  // 推挽
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9 | GPIO_Pin_10;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;    // 上拉
	GPIO_InitStructure.GPIO_Speed = GPIO_High_Speed;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	// 4) 串口参数初始化：设置波特率，字长，奇偶校验等参数。
	USART_InitStructure.USART_BaudRate = baudrate;  // 波特率
	USART_InitStructure.USART_HardwareFlowControl = 
	USART_HardwareFlowControl_None;  // 无流控
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	USART_InitStructure.USART_Parity = USART_Parity_No;     // 无校验
	USART_InitStructure.USART_StopBits = USART_StopBits_1;  // 1 位停止位
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_Init(USART1, &USART_InitStructure);
	
	// 5) 使能串口。
	USART_Cmd(USART1, ENABLE);
}

// 收发函数
// void USART_SendData(USART_TypeDef* USARTx, uint16_t Data);
// uint16_t USART_ReceiveData(USART_TypeDef* USARTx);

// 状态检测函数
// FlagStatus USART_GetFlagStatus(USART_TypeDef* USARTx, uint16_t USART_FLAG);
// void USART_ClearFlag(USART_TypeDef* USARTx, uint16_t USART_FLAG);

/**
 * 功能：  获取 USART1 一个字节数据
 * 参数：  无
 * 返回值：从 USART1 获取的一个字节数据
 **/
int usart1_getchar(void)
{
	int ch;
	
	// 等待接收缓冲区非空标志
	// USART_GetFlagStatus() 函数对于 USART_FLAG_RXNE 标志，
	// 返回 SET 表示有数据，RESET 表示无数据
	while (RESET == USART_GetFlagStatus(USART1, USART_FLAG_RXNE));
	//while (SET != USART_GetFlagStatus(USART1, USART_FLAG_RXNE));
	// 获取一个字节
	ch = USART_ReceiveData(USART1);
	// 回显
	usart1_putchar(ch);
	if (ch == '\r')
	{
		usart1_putchar('\n');
	}
	
	return ch;
}

/**
 * 功能：  从 USART1 发送一字节数据 data
 * 参数：  data 要发送的一字节数据
 * 返回值：成功返回 0，失败返回 -1
 **/
int usart1_putchar(int data)
{
	if (data == '\n')
	{
		usart1_putchar('\r');
	}
	// 等待发送空标志
	// USART_GetFlagStatus() 函数对于 USART_FLAG_TXE 标志，
	// 返回 SET 表示可以发送数据，RESET 表示不能发送数据
	while (RESET == USART_GetFlagStatus(USART1, USART_FLAG_TXE));
	// 发送数据
	USART_SendData(USART1, data);
	
	return 0;
}

/**
 * 功能：  从 USART1 获取字符串存入 buf 中
 * 参数：  buf 字符指针，用于存储接收的数据
 * 返回值：成功返回 0，失败返回 -1
 **/ 
int usart1_gets(char *buf)
{
	while ('\r' != (*buf++ = usart1_getchar()));
	buf--;
	*buf = '\0';
	
	return 0;
}

/**
 * 功能：  从 USART1 发送字符串 buf
 * 参数：  buf 字符指针，用于存储发送的数据
 * 返回值：成功返回 0，失败返回 -1
 **/ 
int usart1_puts(char *buf)
{
	while (*buf)
	{
		usart1_putchar(*buf++);
	}
	
	return 0;
}

/**
 * 功能：  模仿标准格式化输出函数 printf 
 * 参数：  format 格式化字符串
 * 返回值：成功返回格式化成功的字符个数，失败返回 -1
 **/
int usart1_printf(const char *format, ...)
{
	va_list ap;
	char buf[64];
	int cnt;
	
	va_start(ap, format);
	// 将 format 格式字符串生成的字符串存入 buf 中
	cnt = vsnprintf(buf, sizeof buf, format, ap);
	va_end(ap);
	// 输出转换后的字符串
	if (cnt > 0)
	{
		usart1_puts(buf);
	}
	
	return cnt;
}

// --------------------------------------------------------
// 将标准输入输出重定向到 USART1 

// keil 的安装目录，如：C:\Keil_v5\ARM\Startup 下有一个文件
// Retarget.c。
// 此文件中有重定向标准输入输出到开发板的输入输出的示例
// 以下是复制此文件并做修改。
#if 1
#include <stdio.h>
#include <time.h>
#include <rt_misc.h>

// 不使用“半主机函数”
#pragma import(__use_no_semihosting_swi)


//extern int  sendchar(int ch);  /* in Serial.c */
//extern int  getkey(void);      /* in Serial.c */
extern long timeval;           /* in Time.c   */


struct __FILE { int handle; /* Add whatever you need here */ };
FILE __stdout;
FILE __stdin;

// 打印字符
int fputc(int ch, FILE *f) {
  //return (sendchar(ch));
	return usart1_putchar(ch);
}

// 获取字符
int fgetc(FILE *f) {
  //return (sendchar(getkey()));
	return usart1_getchar();
}

// 判断错误
int ferror(FILE *f) {
  /* Your implementation of ferror */
  return EOF;
}


void _ttywrch(int ch) {
  //sendchar (ch);
	usart1_putchar(ch);
}


void _sys_exit(int return_code) {
  while (1);    /* endless loop */
}
#endif
