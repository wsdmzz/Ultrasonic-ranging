#include "wwdg.h"
#include "led3.h"

#if 0

/*  Function used to set the WWDG configuration to the default reset state ****/  
void WWDG_DeInit(void);

/* Prescaler, Refresh window and Counter configuration functions **************/
void WWDG_SetPrescaler(uint32_t WWDG_Prescaler);
void WWDG_SetWindowValue(uint8_t WindowValue);
void WWDG_EnableIT(void);
void WWDG_SetCounter(uint8_t Counter);

/* WWDG activation function ***************************************************/
void WWDG_Enable(uint8_t Counter);

/* Interrupts and flags management functions **********************************/
FlagStatus WWDG_GetFlagStatus(void);
void WWDG_ClearFlag(void);

#endif

// 计数值
uint8_t WWDG_COUNTER = 0x7F;

/**
 * 功能：  初始化窗口看门狗
 * 参数：  prescaler    预分频值：
 *             WWDG_Prescaler_1: 计数时钟 = (PCLK1/4096)/1
 *             WWDG_Prescaler_2: 计数时钟 = (PCLK1/4096)/2
 *             WWDG_Prescaler_4: 计数时钟 = (PCLK1/4096)/4
 *             WWDG_Prescaler_8: 计数时钟 = (PCLK1/4096)/8
 *         window_value 窗口值：[0x40, 0x7f]
 *         counter      计数值：[0x40, 0x7f]
 * 返回值：无
 **/
void WWDG_init(uint32_t prescaler, uint8_t window_value, uint8_t counter)
{
	NVIC_InitTypeDef NVIC_InitTypeStructure;
	
	WWDG_COUNTER &= counter;
	
	// 使能 WWDG 时钟
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_WWDG, ENABLE);
	// 设置预分频系数
	WWDG_SetPrescaler(prescaler);
	// 设置窗口值
	WWDG_SetWindowValue(window_value);
	// 设置计数值，即喂狗
	//WWDG_SetCounter(counter);
	// 使能窗口看门狗，同时使能看门狗并设置计数值
	// 在中断配置前使能看门狗
	WWDG_Enable(WWDG_COUNTER);
	
	// 初始化中断
	NVIC_InitTypeStructure.NVIC_IRQChannel = WWDG_IRQn;
	NVIC_InitTypeStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitTypeStructure.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitTypeStructure.NVIC_IRQChannelSubPriority = 2;
	NVIC_Init(&NVIC_InitTypeStructure);
	WWDG_ClearFlag();
	WWDG_EnableIT();
}

int flag = 1;

// 窗口看门狗中断处理程序
void WWDG_IRQHandler(void)
{
	// 是"提前唤醒中断"
	if (WWDG_GetFlagStatus())
	{
		// 先清除中断标志 
		WWDG_ClearFlag();
		// 再喂狗
		WWDG_SetCounter(WWDG_COUNTER);
		if (flag)
		{
			LED3_1_ON();
			LED3_3_OFF();
			flag = 0;
		}
		else
		{
			LED3_1_OFF();
			LED3_3_ON();
			flag = 1;
		}
	}
}
