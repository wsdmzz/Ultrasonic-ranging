#ifndef _WWDG_H_
#define _WWDG_H_

#include "stm32f4xx.h"

/**
 * 功能：  初始化窗口看门狗
 * 参数：  prescaler    预分频值：
 *             WWDG_Prescaler_1: 计数时钟 = (PCLK1/4096)/1
 *             WWDG_Prescaler_2: 计数时钟 = (PCLK1/4096)/2
 *             WWDG_Prescaler_4: 计数时钟 = (PCLK1/4096)/4
 *             WWDG_Prescaler_8: 计数时钟 = (PCLK1/4096)/8
 *         window_value 窗口值：[0x40, 0x7f]
 *         counter      计数值：[0x40, 0x7f]
 * 返回值：无
 **/
void WWDG_init(uint32_t prescaler, uint8_t window_value, uint8_t counter);

#endif
